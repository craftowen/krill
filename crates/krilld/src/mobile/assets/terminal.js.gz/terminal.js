// Orca mobile interaction/theme reference: MIT, Copyright (c) 2026 Lovecast Inc.
// See docs/research/orca-mobile-ui-spec.md §5.1 for the MIT notice.
// Icons: Lucide (ISC), Copyright (c) Lucide Contributors, from gpui-kit-assets.

// Soft keyboard = the strip the visual viewport leaves uncovered at the bottom (Orca keyboard-occlusion.web.ts).
// One reader per frame writes --keyboard-inset on <html>; the fixed shell shrinks by it, so nothing else measures the keyboard.
globalThis.MkKeyboard=(()=>{
 const vv=globalThis.visualViewport,doc=globalThis.document,raf=globalThis.requestAnimationFrame?.bind(globalThis)||(fn=>setTimeout(fn,16)),listeners=new Set(),field=n=>!!n?.matches?.('input,textarea,[contenteditable]:not([contenteditable=false])');let inset=0,frame=0,resized=false;
 // 핀치 줌(scale≠1)은 키보드와 기하가 같아 구분할 수 없으므로 0으로 본다. scale이 없는 WebView는 1이다. offsetTop은 내려간 시각 뷰포트 아래 띠를 키보드로 세지 않게 뺀다.
 const occlusion=()=>!vv||Math.abs((vv.scale??1)-1)>.01?0:Math.max(0,Math.round(innerHeight-vv.height-vv.offsetTop));
 const measure=()=>{frame=0;let next=occlusion();
  // iOS는 포커스한 입력을 키보드 위로 보이려고 문서를 민다. 셸은 고정이고 dock·composer·sheet는 inset만큼 스스로 올라가므로 문서 위치를 되돌린다.
  if(next>0&&doc?.activeElement?.closest?.('.command-dock,.chat-composer,.sheet,.workspace-search,.gate-card')&&((globalThis.scrollY||0)>0||(vv.offsetTop||0)>0)){globalThis.scrollTo?.(0,0);next=occlusion();}
  const changed=next!==inset,notify=changed||resized;resized=false;if(changed){inset=next;doc?.documentElement?.style.setProperty('--keyboard-inset',`${inset}px`);}
  // 스크롤·포커스만 있었던 프레임은 알리지 않는다(구독자의 Fit 디바운스를 다시 걸지 않게).
  if(notify)for(const fn of listeners)fn(inset);};
 const schedule=e=>{if(e?.type==='resize'||e?.type==='orientationchange')resized=true;if(!frame)frame=raf(measure);};
 if(vv){vv.addEventListener('resize',schedule);vv.addEventListener('scroll',schedule);}for(const type of ['resize','orientationchange'])globalThis.addEventListener?.(type,schedule);for(const type of ['focusin','focusout'])doc?.addEventListener?.(type,schedule);
 return Object.freeze({inset:()=>inset,subscribe(fn){listeners.add(fn);return ()=>listeners.delete(fn);},
  // Orca keyboard-persisting-taps('handled'): 입력 중 버튼 tap이 포커스를 가져가 키보드를 닫거나 첫 tap을 삼키지 않게 한다. click은 그대로 온다.
  keepFocus(container,signal){container?.addEventListener?.('mousedown',e=>{const b=e.target?.closest?.('button');if(b&&container.contains(b)&&field(doc?.activeElement)&&!field(e.target))e.preventDefault();},{capture:true,signal});}});
})();

// The live stream uses the same postcard DTOs as desktop; no terminal emulation or query replies.
globalThis.MkTerminalCodec=(()=>{
 const C=MkCrypto,decoder=new TextDecoder('utf-8',{fatal:true});
 const v=value=>{let n=BigInt(value),out=[];do{const b=Number(n&127n);n>>=7n;out.push(b|(n?128:0));}while(n);return Uint8Array.from(out);};
 const text=s=>{const b=C.enc.encode(s);return C.concat(v(b.length),b);};
 const frame=(kind,body=new Uint8Array())=>{const h=new Uint8Array(5);new DataView(h.buffer).setUint32(0,body.length+1,true);h[4]=kind;return C.concat(h,body);};
 function reader(bytes){let at=0;return {
  u(){let n=0n,shift=0n;for(let i=0;i<10;i++){if(at>=bytes.length)throw Error('Truncated screen');const b=bytes[at++];n|=BigInt(b&127)<<shift;if(!(b&128))return n;shift+=7n;}throw Error('Invalid screen integer');},
  n(max=Number.MAX_SAFE_INTEGER){if(at<bytes.length&&bytes[at]<128){const n=bytes[at++];if(n>max)throw Error('Screen limit');return n;}const n=Number(this.u());if(!Number.isSafeInteger(n)||n>max)throw Error('Screen limit');return n;},
  byte(){if(at>=bytes.length)throw Error('Truncated screen');return bytes[at++];},
  bool(){const n=this.byte();if(n>1)throw Error('Invalid boolean');return !!n;},
  text(max=4096){const n=this.n(max);if(at+n>bytes.length)throw Error('Truncated screen text');const s=n===0?'':n===1&&bytes[at]<128?String.fromCharCode(bytes[at]):decoder.decode(bytes.subarray(at,at+n));at+=n;return s;},
  end(){if(at!==bytes.length)throw Error('Trailing screen data');}
 };}
 function color(r){switch(r.n(2)){case 0:return null;case 1:return {index:r.byte()};case 2:return `rgb(${r.byte()},${r.byte()},${r.byte()})`;}}
 // NFD 한글(맥 파일 이름 등)은 초성 칸에 중성·종성이 폭 0 문자로 붙어 온다. 글꼴 조합에 맡기지 않고 NFC로 합쳐 한 글자로 그린다.
 function cells(r){return Array.from({length:r.n(2048)},()=>{const ch=r.text(4),zero=Array.from({length:r.n(8)},()=>r.text(4)).join('');return {ch,zero,text:zero?(ch+zero).normalize('NFC'):ch,fg:color(r),bg:color(r),underline:color(r),flags:r.n(65535)};});}
 function update(bytes,model){const r=reader(bytes);model.revision=r.u();model.seq=r.u();const done=r.bool(),dirty=new Set();for(let count=r.n(100000);count--;){switch(r.n(7)){
  case 0:{const cols=r.n(2048),lines=r.n(1024);if(!cols||!lines)throw Error('Invalid size');Object.assign(model,{cols,lines,rows:Array.from({length:lines},()=>[]),cursor:{line:0,column:0,visible:true}});for(let i=0;i<lines;i++)dirty.add(i);break;}
  case 1:{const z=r.n(65535),n=(z>>>1)^-(z&1),k=Math.abs(n);if(k>=model.lines)throw Error('Invalid scroll');if(n>0)model.rows=[...model.rows.slice(k),...Array.from({length:k},()=>[])];else model.rows=[...Array.from({length:k},()=>[]),...model.rows.slice(0,model.lines-k)];for(let i=0;i<model.lines;i++)dirty.add(i);break;}
  case 2:{const line=r.n(1023),row=cells(r);if(line>=model.lines||row.length>model.cols)throw Error('Invalid dirty row');model.rows[line]=row;dirty.add(line);break;}
  case 3:{const cursor={line:r.n(1023),column:r.n(2047),visible:r.bool()};if(cursor.line>=model.lines||cursor.column>=model.cols)throw Error('Invalid cursor');model.cursor=cursor;break;}
  case 4:model.title=r.text(1024);break;
  case 5:break;
  case 6:model.cursorStyle={shape:r.n(2),blink:r.bool()};break;
  case 7:r.n(1023);for(let n=r.n(2048);n--;){r.n(2047);r.n(2048);r.text(2048);}break;
 }}r.end();return {done,dirty};}
 function history(bytes){const r=reader(bytes),reply={req:r.n(0xffffffff),total:r.n(0xffffffff),pages:r.n(0xffffffff),skip:r.n(0xffffffff)};reply.rows=Array.from({length:r.n(1000)},()=>cells(r));r.end();return reply;}
 return {v,text,frame,reader,update,history};
})();

(()=>{
 'use strict';
 const T=MkTerminalCodec,C=MkCrypto,UI_KEY='krill-mobile-ui-v1';
 const SCALES=Object.freeze([.5,.75,1,1.25,1.5,2]),drafts=new Map(),modes=new Map(),instances=new Set(),uncertainInputs=new Set();
 const KEYS=Object.freeze([
  ['escape','Esc','\x1b'],['tab','Tab','\t'],['enter','Enter','\r'],['shiftTab','Shift+Tab','\x1b[Z'],['space','Space',' '],
  ['backspace','⌫','\x7f',true],['delete','Del','\x1b[3~',true],['arrowUp','↑','\x1b[A',true],['arrowDown','↓','\x1b[B',true],
  ['arrowLeft','←','\x1b[D',true],['arrowRight','→','\x1b[C',true],
  ['home','Home','\x1b[H'],['end','End','\x1b[F'],['pageUp','PgUp','\x1b[5~',true],['pageDown','PgDn','\x1b[6~',true],['ctrlC','Ctrl+C','\x03'],['ctrlD','Ctrl+D','\x04'],
  ['ctrlL','Ctrl+L','\x0c'],['ctrlZ','Ctrl+Z','\x1a'],['ctrlR','Ctrl+R','\x12'],['ctrlA','Ctrl+A','\x01'],
  ['ctrlE','Ctrl+E','\x05'],['ctrlW','Ctrl+W','\x17'],['ctrlU','Ctrl+U','\x15']
 ].map(([id,label,bytes,repeatable=false])=>Object.freeze({id,label,bytes,repeatable})));
 // Physical and accessory keys share one modifier encoding (xterm: 1 + Shift 1 + Alt 2 + Ctrl 4). A bare Shift keeps the old forms.
 function encodeKey(bytes,mods=false){const {shift=false,alt=false,ctrl=false}=typeof mods==='boolean'?{shift:mods}:mods;if(!shift&&!alt&&!ctrl)return bytes;const n=1+(shift?1:0)+(alt?2:0)+(ctrl?4:0),letter=/^\x1b\[([ABCDHF])$/.exec(bytes),tilde=/^\x1b\[(\d+)~$/.exec(bytes);
  if(letter)return `\x1b[1;${n}${letter[1]}`;if(tilde)return `\x1b[${tilde[1]};${n}~`;if(bytes==='\t'&&shift)return (alt?'\x1b':'')+'\x1b[Z';if(bytes==='\r'&&shift)return `\x1b[13;${n}u`;if(bytes==='\x7f'&&ctrl)return (alt?'\x1b':'')+'\x08';return (alt?'\x1b':'')+bytes;}
 // Ctrl+글자는 C0 제어 문자로 바꾼다(Ctrl+@…_ , Ctrl+Space=NUL, Ctrl+?=DEL). 바꿀 수 없는 글자는 그대로 둔다.
 function controlChar(ch){if(ch===' '||ch==='@'||ch==='2')return '\x00';if(ch==='?')return '\x7f';const code=ch.toUpperCase().charCodeAt(0);return ch.length===1&&code>=64&&code<=95?String.fromCharCode(code-64):ch;}
 const icons={"monitor":[["rect",{"width":"20","height":"14","x":"2","y":"3","rx":"2"}],["line",{"x1":"8","x2":"16","y1":"21","y2":"21"}],["line",{"x1":"12","x2":"12","y1":"17","y2":"21"}]],"smartphone":[["rect",{"width":"14","height":"20","x":"5","y":"2","rx":"2","ry":"2"}],["path",{"d":"M12 18h.01"}]],"keyboard":[["path",{"d":"M10 8h.01"}],["path",{"d":"M12 12h.01"}],["path",{"d":"M14 8h.01"}],["path",{"d":"M16 12h.01"}],["path",{"d":"M18 8h.01"}],["path",{"d":"M6 8h.01"}],["path",{"d":"M7 16h10"}],["path",{"d":"M8 12h.01"}],["rect",{"width":"20","height":"16","x":"2","y":"4","rx":"2"}]],"dismiss":[["path",{"d":"M 20 4 A2 2 0 0 1 22 6"}],["path",{"d":"M 22 6 L 22 16.41"}],["path",{"d":"M 7 16 L 16 16"}],["path",{"d":"M 9.69 4 L 20 4"}],["path",{"d":"M14 8h.01"}],["path",{"d":"M18 8h.01"}],["path",{"d":"m2 2 20 20"}],["path",{"d":"M20 20H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2"}],["path",{"d":"M6 8h.01"}],["path",{"d":"M8 12h.01"}]],"send":[["path",{"d":"m5 12 7-7 7 7"}],["path",{"d":"M12 19V5"}]],"photo":[["rect",{"width":"18","height":"18","x":"3","y":"3","rx":"2","ry":"2"}],["circle",{"cx":"9","cy":"9","r":"2"}],["path",{"d":"m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"}]]};
 icons.edit=[['path',{d:'M10 5H3M12 19H3M14 3v4M16 17v4M21 12h-9M21 19h-5M21 5h-7M8 10v4M8 12H3'}]];
 const make=(tag,cls,text)=>{const el=document.createElement(tag);if(cls)el.className=cls;if(text!==undefined)el.textContent=text;return el;};
 function icon(name){const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');for(const [k,v] of Object.entries({viewBox:'0 0 24 24',width:'16',height:'16',fill:'none',stroke:'currentColor','stroke-width':'2','stroke-linecap':'round','stroke-linejoin':'round','aria-hidden':'true'}))svg.setAttribute(k,v);for(const [tag,attrs] of icons[name]){const shape=document.createElementNS(svg.namespaceURI,tag);for(const [key,value] of Object.entries(attrs))shape.setAttribute(key,value);svg.append(shape);}return svg;}
 const translate=s=>globalThis.KrillMobile?.i18n?.t(s)||s;
 function button(cls,label,svg){label=translate(label);const el=make('button',cls,svg?undefined:label);el.type='button';el.setAttribute('aria-label',label);el.title=label;if(svg)el.append(icon(svg));return el;}
 function settings(){try{const value=JSON.parse(localStorage.getItem(UI_KEY)||'{}');return value&&typeof value==='object'&&!Array.isArray(value)?value:{};}catch{return {};}}
 const FAMILY='ui-monospace, "SF Mono", Menlo, Monaco, "Cascadia Mono", Consolas, "DejaVu Sans Mono", "Liberation Mono", "Symbols Nerd Font Mono", monospace';
 // 터치·좁은 화면은 연결되면 폰 크기에 맞춘다. 사용자가 Fit을 끄면 그 선택(preferences.fitToPhone)이 우선한다.
 const phoneLike=()=>!!globalThis.matchMedia?.('(pointer: coarse)')?.matches||(globalThis.innerWidth||Infinity)<600;
 const snap=value=>SCALES.reduce((best,n)=>Math.abs(n-value)<Math.abs(best-value)?n:best,1);
 class Terminal {
  constructor(root,options){
   if(!root||!Number.isSafeInteger(options.sessionId)||options.sessionId<=0||typeof options.connect!=='function')throw Error('Invalid terminal mount');
   this.root=root;this.options=options;this.session=options.sessionId;this.stateKey=options.stateKey??this.session;this.generation=1;this.inputGeneration=1;this.disposed=false;this.visible=options.visible!==false;
   this.abort=new AbortController();this.model={cols:80,lines:24,rows:[],cursor:{visible:false}};this.fit=false;this.ready=false;this.stick=true;this.autoFit=options.preferences?.fitToPhone??phoneLike();this.fontScale=snap(Number(options.preferences?.textScale)||1);
   this.dirty=new Set();this.full=true;this.inputId=0;this.historyId=0;this.pendingInputs=new Map();this.pendingRoles=[];this.deferredKeys=[];this.phase='connecting';
   this.contextBlocked=uncertainInputs.has(this.stateKey);
   const stored=settings().terminalInputModes?.[this.stateKey],initial=options.preferences?.inputMode||modes.get(this.stateKey)||stored;
   this.inputMode=initial==='buffered'?'buffered':'direct';modes.set(this.stateKey,this.inputMode);
   this.build();this.resetHistory();this.bindInput();this.bindViewport();this.setFontScale(this.fontScale,false);this.updateMode();this.status('connecting','Connecting…');
   this.open();
  }
  listen(el,event,fn,extra={}){el.addEventListener(event,fn,{...extra,signal:this.abort.signal});}
  guard(action){const generation=this.generation;try{Promise.resolve(action()).catch(e=>{if(!this.disposed&&generation===this.generation)this.error(e);});}catch(e){if(generation===this.generation)this.error(e);}}
  status(phase,message,error){if(this.disposed)return;const waiting=phase==='ready'&&this.inputWaiting;message=translate(waiting?'Waiting for input confirmation…':message);this.phase=phase;this.root.dataset.phase=waiting?'input-pending':phase;this.statusEl.textContent=message;this.statusEl.setAttribute('role',error?'alert':'status');this.options.onStatus?.({phase,message,error,fit:this.fit,inputMode:this.inputMode,fontScale:this.fontScale,typing:!!this.wasTyping});}
  error(e){this.status('error',e.message||String(e),e);}
  build(){
   this.root.classList.add('terminal-mount');this.frame=make('div','terminal-frame');this.port=make('div','terminal-scroll');this.port.tabIndex=0;
   this.historyElement=make('pre','terminal-history');this.canvas=make('canvas','terminal-grid');this.canvas.setAttribute('role','img');this.ctx=this.canvas.getContext('2d');
   this.statusEl=make('div','terminal-status');this.statusEl.dataset.testid='terminal-status';
   this.recoverButton=button('ghost small','Resume input');this.recoverButton.hidden=true;this.listen(this.recoverButton,'click',()=>{if(!this.ready||!this.isVisible())return;this.contextBlocked=false;uncertainInputs.delete(this.stateKey);this.recoverButton.hidden=true;this.status('ready',`${this.model.cols} × ${this.model.lines}`);this.focus();});
   // 이전 출력 컨트롤은 스크롤 내용 맨 위에 두고 처음 불러올 때까지 숨긴다. 터미널 아래 상시 한 줄을 먹지 않게 한다(맨 위에서 끌어내리거나 액션 시트로 첫 로드).
   const controls=this.historyControls=make('div','terminal-history-controls');this.historyButton=button('load-history','Load earlier output');this.historyStatus=make('span','history-status');this.historyStatus.setAttribute('role','status');controls.append(this.historyButton,this.historyStatus);this.port.append(controls,this.historyElement,this.canvas);this.latestButton=button('terminal-latest','Latest output');this.latestButton.hidden=true;this.listen(this.latestButton,'pointerdown',e=>e.preventDefault());this.listen(this.latestButton,'click',()=>this.returnToLive());this.frame.append(this.port,this.latestButton,this.statusEl,this.recoverButton);
   this.dock=make('footer','command-dock');const accessory=make('div','accessory-row');this.dismiss=button('dismiss-keyboard','Dismiss keyboard','dismiss');this.dismiss.hidden=true;
   const keybar=make('div','keybar');keybar.setAttribute('role','toolbar');keybar.setAttribute('aria-label','Terminal keys');this.fitButton=button('accessory-key display-mode','Fit to Phone','monitor');this.fitButton.setAttribute('aria-pressed','false');this.directButton=button('accessory-key direct-toggle','Direct input');this.shiftButton=button('accessory-key shift-toggle','Shift');this.shiftButton.dataset.keyId='shift';this.shiftButton.dataset.testid='terminal-key-shift';this.shiftButton.setAttribute('aria-pressed','false');
   // Ctrl·Alt는 Shift처럼 다음 입력 한 번에만 붙는 고정 수정자다. 키보드로 친 글자와 키 줄 키 모두에 적용된다.
   this.modifierButtons={shift:this.shiftButton};for(const [name,label] of [['ctrl','Ctrl'],['alt','Alt']]){const b=this.modifierButtons[name]=button(`accessory-key ${name}-toggle`,label);b.dataset.keyId=name;b.dataset.testid=`terminal-key-${name}`;b.setAttribute('aria-pressed','false');this.listen(b,'pointerdown',e=>e.preventDefault());this.listen(b,'click',()=>this.toggleModifier(name));}
   keybar.append(this.fitButton,this.directButton,this.shiftButton,this.modifierButtons.ctrl,this.modifierButtons.alt);
   const ordered=this.options.preferences?.orderedKeyIds||[],visible=this.options.preferences?.visibleKeyIds;
   const ids=[...new Set([...ordered,...KEYS.map(k=>k.id)])];for(const id of ids){const key=KEYS.find(k=>k.id===id);if(!key||visible&&!visible.includes(id))continue;const b=button('accessory-key',key.label);b.dataset.keyId=id;b.dataset.testid=`terminal-key-${id}`;keybar.append(b);this.bindKey(b,key);}
   // 직접 입력의 키보드 열기는 키 줄 왼쪽 고정 버튼이다(열리면 Dismiss로 바뀜). 별도 입력 줄은 buffered에서만 보여 터미널 행을 더 쓴다.
   this.live=button('dismiss-keyboard show-keyboard','Show keyboard','keyboard');accessory.append(this.dismiss,this.live,keybar);const inputRow=this.inputRow=make('div','input-row');
   this.capture=make('textarea','live-capture');this.capture.rows=1;this.capture.tabIndex=-1;this.capture.setAttribute('aria-label',translate('Terminal direct input'));this.capture.setAttribute('autocapitalize','none');this.capture.setAttribute('autocorrect','off');this.capture.setAttribute('autocomplete','off');this.capture.spellcheck=false;
   this.form=make('form','buffered-command');this.command=make('textarea','command-input');this.command.rows=1;this.command.placeholder=translate('Type a command…');this.command.setAttribute('aria-label',translate('Command'));this.command.setAttribute('enterkeyhint','enter');this.command.autocomplete='off';this.command.setAttribute('autocapitalize','none');this.command.spellcheck=false;this.command.value=drafts.get(this.stateKey)||'';
   this.sendButton=button('command-send','Send command','send');this.sendButton.type='submit';this.form.append(this.command,this.sendButton);inputRow.append(this.form);
   if(this.options.onPhoto){const photo=button('photo-attach','Attach photo','photo'),images=make('input','photo-picker'),files=make('input','file-picker');images.type=files.type='file';images.accept=files.accept='image/*';images.setAttribute('aria-label',translate('Choose photo'));files.setAttribute('aria-label',translate('Choose image file'));images.hidden=files.hidden=true;accessory.append(photo);accessory.append(images,files);let held=false,timer;
    this.listen(photo,'pointerdown',()=>{held=false;timer=setTimeout(()=>{held=true;(globalThis.KrillMobile?.updates?.pickFile||((p)=>p.click()))(files);},350);});for(const event of ['pointerup','pointercancel','pointerleave'])this.listen(photo,event,()=>clearTimeout(timer));this.listen(photo,'click',()=>{if(!held)(globalThis.KrillMobile?.updates?.pickFile||((p)=>p.click()))(images);});this.listen(this.abort.signal,'abort',()=>clearTimeout(timer));
    for(const picker of [images,files])this.listen(picker,'change',()=>{const file=picker.files?.[0];if(file)this.guard(()=>this.options.onPhoto(file));picker.value='';});
   }
   if(this.options.onEditKeys){const edit=button('accessory-key edit-keys','Edit terminal keys','edit');keybar.append(edit);this.listen(edit,'click',()=>this.options.onEditKeys());}
   this.dock.append(accessory,inputRow,this.capture);this.root.append(this.frame,this.dock);
   let lastTop=0;this.listen(this.historyButton,'click',()=>this.guard(()=>this.loadHistory()));this.listen(this.port,'scroll',()=>{const top=this.port.scrollTop,up=top<lastTop,refresh=up&&this.stick&&this.historyLoadedVersion!==this.historyVersion;const now=globalThis.performance?.now?.()??Date.now(),elapsed=now-(this.historyScrollAt??now);this.historyVelocity=up&&elapsed>0?(lastTop-top)/elapsed:0;this.historyScrollAt=now;lastTop=top;this.stick=this.atBottom(1);this.latestButton.hidden=this.stick;if(refresh||up&&top<this.historyThreshold())this.guard(()=>this.loadHistory(false,refresh));},{passive:true});
   for(const b of [this.fitButton,this.directButton,this.shiftButton,this.historyButton])this.listen(b,'pointerdown',e=>e.preventDefault());this.listen(this.shiftButton,'click',()=>this.toggleShift());
   this.listen(this.fitButton,'click',()=>this.guard(()=>this.fitToPhone()));this.listen(this.directButton,'click',()=>this.setInputMode(this.inputMode==='direct'?'buffered':'direct'));
   this.listen(this.dismiss,'click',()=>{this.capture.blur();this.command.blur();});this.listen(this.live,'click',()=>this.focus());
   // 터미널을 탭하거나 스크롤해도 키보드를 열지 않는다(Orca). 키보드는 키 줄 왼쪽 키보드 버튼으로만 연다.
   // 가로는 네이티브 스크롤을 막고(CSS overflow-x:hidden·pan-y) 한 손가락 제스처를 한 축에 고정해 손가락만큼만 옮긴다. 관성·바운스가 없어 세로로 쓸 때 좌우로 흔들리지 않는다.
   let pan;this.listen(this.port,'wheel',e=>{if(e.deltaY<0&&(this.atBottom()&&this.historyLoadedVersion!==this.historyVersion||this.port.scrollTop<this.historyThreshold()))this.guard(()=>this.loadHistory(false,this.atBottom()&&this.historyLoadedVersion!==this.historyVersion));if(Math.abs(e.deltaX)>Math.abs(e.deltaY)){e.preventDefault();this.port.scrollLeft+=e.deltaX;}},{passive:false});
   let pinch;const distance=touches=>Math.hypot(touches[0].clientX-touches[1].clientX,touches[0].clientY-touches[1].clientY);
   this.listen(this.port,'touchstart',e=>{pan=e.touches.length===1?{x:e.touches[0].clientX,y:e.touches[0].clientY,left:this.port.scrollLeft,axis:null,live:this.atBottom()}:null;if(e.touches.length===2){pinch={distance:distance(e.touches),scale:this.fontScale};this.pinching=true;}},{passive:true});
   this.listen(this.port,'touchmove',e=>{if(pinch&&e.touches.length===2){e.preventDefault();this.previewScale=Math.max(.5,Math.min(2,pinch.scale*distance(e.touches)/pinch.distance));this.canvas.style.transformOrigin='top left';this.canvas.style.transform=`scale(${this.previewScale/this.fontScale})`;return;}if(!pan||e.touches.length!==1)return;const dx=e.touches[0].clientX-pan.x,dy=e.touches[0].clientY-pan.y;if(!pan.axis&&Math.hypot(dx,dy)>6)pan.axis=Math.abs(dx)>Math.abs(dy)?'x':'y';if(pan.axis==='x'){if(e.cancelable)e.preventDefault();this.port.scrollLeft=pan.left-dx;}else if(pan.axis==='y'&&this.wheel(e.touches[0],pan)){if(e.cancelable)e.preventDefault();}else if(pan.axis==='y'&&dy>6&&!pan.pulled&&(pan.live||this.port.scrollTop<this.historyThreshold())){pan.pulled=true;this.stick=false;this.latestButton.hidden=false;this.guard(()=>this.loadHistory(false,pan.live&&this.historyLoadedVersion!==this.historyVersion));}},{passive:false});
   const finish=()=>{pan=null;if(!pinch)return;pinch=null;this.canvas.style.transform='';this.setFontScale(this.previewScale||this.fontScale);setTimeout(()=>{this.pinching=false;},0);};this.listen(this.port,'touchend',finish);this.listen(this.port,'touchcancel',finish);
  }
  wheel(t,pan){const f=this.termModes?.flags||0;if(!(f&14)||!(f&16))return false;const y=t.clientY,h=this.cellHeight||18,up=y>(pan.wy??=y);if(up?this.port.scrollTop>0:!this.atBottom()){pan.wy=y;return false;}const n=Math.trunc((y-pan.wy)/h);if(!n)return true;pan.wy+=n*h;const r=this.canvas.getBoundingClientRect?.()||{left:0,top:0},m=this.model,at=(v,max)=>Math.max(1,Math.min(max,Math.floor(v)+1));this.guard(()=>this.input(`\x1b[<${n>0?64:65};${at((t.clientX-r.left)/(this.cellWidth||8),m.cols)};${at((y-r.top)/h,m.lines)}M`.repeat(Math.min(Math.abs(n),100)),false));return true;}
  stopRepeat(){clearTimeout(this.repeatTimer);this.repeatToken=(this.repeatToken||0)+1;this.heldPointer=null;}
  bindKey(el,key){
   this.listen(el,'pointerdown',e=>{e.preventDefault();if(e.button!==0)return;this.stopRepeat();if(!key.repeatable)return;this.heldPointer=e.pointerId;el.setPointerCapture?.(e.pointerId);const token=this.repeatToken;
    const tick=async()=>{try{await this.sendKey(key.id);if(token===this.repeatToken&&!this.disposed)this.repeatTimer=setTimeout(tick,45);}catch(e){if(token===this.repeatToken){this.stopRepeat();this.error(e);}}};
    const initial=this.sendKey(key.id);initial.catch(e=>{if(token===this.repeatToken){this.stopRepeat();this.error(e);}});this.repeatTimer=setTimeout(()=>{initial.then(()=>{if(token===this.repeatToken&&!this.disposed)tick();},()=>{});},400);
   });
   this.listen(el,'click',e=>{if(!key.repeatable||e.detail===0)this.guard(()=>this.sendKey(key.id));});
   for(const event of ['pointerup','pointercancel','lostpointercapture','pointerleave'])this.listen(el,event,()=>this.stopRepeat());
  }
  bindInput(){
   // 직접 입력은 textarea를 매번 비우지 않고, 이미 보낸 글자(sent)와 지금 값을 비교해 바뀐 만큼만 보낸다(지운 글자 수만큼 DEL + 새 글자).
   // iOS 한글 키보드처럼 조합 이벤트 없이 앞 글자를 지우고 다시 넣어 음절을 만드는 키보드는 textarea 문맥이 남아 있어야 'ㅎ'+'ㅏ'를 '하'로 바꾼다. 비우면 자모가 따로 들어간다.
   this.listen(this.capture,'focus',()=>{this.resetCapture();this.inputArmed=this.inputActive!==false&&!this.contextBlocked&&!this.pasteReview&&this.isVisible();});
   this.listen(this.capture,'paste',e=>{if(!this.inputArmed||this.inputMode!=='direct'||this.composing)return;const text=e.clipboardData?.getData('text/plain');if(typeof text!=='string')return;e.preventDefault();const value=this.capture.value,start=this.capture.selectionStart??value.length,end=this.capture.selectionEnd??start;this.capture.value=value.slice(0,start)+text+value.slice(end);this.syncCapture(true);});
   this.listen(this.capture,'compositionstart',()=>{if(this.inputActive===false||this.inputMode!=='direct'||this.disposed)return;this.composing=true;this.compositionGeneration=this.inputGeneration;this.compositionConnection=this.generation;});
   this.listen(this.capture,'compositionend',e=>{
    const valid=this.inputArmed&&this.composing&&this.compositionGeneration===this.inputGeneration&&this.compositionConnection===this.generation&&this.inputMode==='direct';this.composing=false;
    if(!valid){const saved=this.inactiveComposition;this.inactiveComposition=null;if(saved&&saved.version===this.bufferedVersion){this.command.value=saved.prefix+(e.data||saved.text);this.command.value?drafts.set(this.stateKey,this.command.value):drafts.delete(this.stateKey);this.sizeCommand();}this.resetCapture();this.deferredKeys.splice(0).forEach(p=>p.reject(Error('Input target changed')));return;}
    this.syncCapture();const keys=this.deferredKeys.splice(0);if(keys.length)this.resetCapture();for(const pending of keys)this.input(pending.bytes).then(pending.resolve,pending.reject);
   });
   this.listen(this.capture,'input',e=>{if(this.disposed||!this.inputArmed||this.inputMode!=='direct'){this.resetCapture();return;}if(this.composing||e.isComposing)return;this.syncCapture(e.inputType==='insertFromPaste');});
   // 지울 글자가 textarea에 있으면 기본 동작으로 지우고 input에서 DEL을 보낸다. 비어 있을 때만 막고 DEL을 바로 보낸다.
   this.listen(this.capture,'beforeinput',e=>{if(!this.inputArmed||this.composing||e.isComposing||this.inputMode!=='direct')return;if(e.inputType==='deleteContentBackward'&&this.capture.value)return;const bytes={deleteContentBackward:'\x7f',deleteContentForward:'\x1b[3~',insertLineBreak:'\r',insertParagraph:'\r'}[e.inputType];if(bytes){e.preventDefault();this.guard(()=>this.controlInput(this.consumeShift(bytes,true)));}});
   this.listen(this.capture,'keydown',e=>{if(!this.inputArmed||this.inputMode!=='direct'||this.composing||e.isComposing||e.keyCode===229||e.metaKey||e.altKey)return;if(e.key==='Backspace'&&this.capture.value)return;let bytes;const special={Escape:'escape',Tab:'tab',Enter:'enter',Backspace:'backspace',Delete:'delete',ArrowUp:'arrowUp',ArrowDown:'arrowDown',ArrowLeft:'arrowLeft',ArrowRight:'arrowRight'}[e.key];if(special)bytes=encodeKey(KEYS.find(k=>k.id===special).bytes,e.shiftKey);else if(e.ctrlKey&&/^[a-z]$/i.test(e.key))bytes=String.fromCharCode(e.key.toUpperCase().charCodeAt(0)-64);if(bytes){e.preventDefault();this.guard(()=>this.controlInput(this.consumeShift(bytes,true)));}});
   this.listen(this.command,'compositionstart',()=>{this.bufferedComposing=true;});this.listen(this.command,'compositionend',()=>{this.bufferedComposing=false;});
   // 일반 입력은 Enter를 textarea의 줄바꿈에 맡기고 보내기 버튼으로만 제출한다.
   this.listen(this.command,'input',()=>{this.bufferedVersion=(this.bufferedVersion||0)+1;this.command.value?drafts.set(this.stateKey,this.command.value):drafts.delete(this.stateKey);this.sizeCommand();});
   this.listen(this.form,'submit',e=>{e.preventDefault();if(this.inputActive===false||e.isComposing||this.bufferedComposing||this.bufferedPending)return;const value=this.command.value;if(!value)return;const generation=this.generation,version=this.bufferedVersion;this.bufferedPending=true;this.sendButton.disabled=true;
    const clean=value.replace(/\r\n?/g,'\n').replace(/[\x00-\x08\x0b-\x1f\x7f]/g,''),bytes=this.termModes?.flags&32?'\x1b[200~'+clean+'\x1b[201~':clean.replace(/\n/g,'\r');
    this.guard(async()=>{try{await this.input(bytes+'\r');if(!this.disposed&&generation===this.generation&&version===this.bufferedVersion&&this.command.value===value){this.command.value='';drafts.delete(this.stateKey);this.sizeCommand();}}finally{this.bufferedPending=false;this.sendButton.disabled=false;}});
   });
  }
  // 자동 높이는 프레임당 한 번만 잰다(키 입력마다 강제 레이아웃을 하지 않는다). 높이가 바뀌면 port의 ResizeObserver가 다시 맞춘다.
  sizeCommand(){if(this.sizeFrame)return;this.sizeFrame=(globalThis.requestAnimationFrame||setTimeout)(()=>{this.sizeFrame=0;if(this.disposed)return;this.command.style.height='auto';this.command.style.height=`${this.command.scrollHeight||34}px`;});}
  updateMode(){this.root.dataset.inputMode=this.inputMode;this.capture.hidden=this.inputMode!=='direct';this.live.hidden=this.capture.hidden||this.root.dataset.keyboardOpen==='true';this.form.hidden=this.inputRow.hidden=this.inputMode==='direct';this.directButton.textContent=translate(this.inputMode==='direct'?'Direct input':'Buffered input');this.directButton.title=this.directButton.textContent;this.directButton.setAttribute('aria-label',this.directButton.title);if(this.inputMode==='buffered')this.sizeCommand();}
  setInputMode(mode){if(this.disposed||!['direct','buffered'].includes(mode)||mode===this.inputMode)return;const typing=[this.capture,this.command].includes(globalThis.document?.activeElement);this.invalidateInput();this.inputMode=mode;modes.set(this.stateKey,mode);const value=settings();value.terminalInputModes={...value.terminalInputModes,[this.stateKey]:mode};try{localStorage.setItem(UI_KEY,JSON.stringify(value));}catch{}this.options.onPreferenceChange?.({inputMode:mode,sessionId:this.session});this.updateMode();if(typing)this.focus();}
  getInputMode(){return this.inputMode;}
  resetCapture(){this.capture.value='';this.sent='';}
  syncCapture(pasted=false){const before=[...this.sent||''],now=this.capture.value,after=[...now];let same=0;while(same<before.length&&same<after.length&&before[same]===after[same])same++;const added=after.slice(same).join(''),removed='\x7f'.repeat(before.length-same);if(pasted||/[\r\n]/.test(added)){this.resetCapture();this.paste(added,removed);return;}if(added&&(this.modifiers?.ctrl||this.modifiers?.alt)){this.resetCapture();const bytes=removed+this.consumeShift(added,false);this.guard(()=>this.input(bytes));return;}this.sent=now;const bytes=removed+(added?this.consumeShift(added,false):'');if(bytes){const generation=this.inputGeneration;this.guard(async()=>{try{await this.input(bytes);}catch(error){if(generation===this.inputGeneration){this.contextBlocked=true;this.invalidateInput();this.recoverButton.hidden=false;}throw error;}});}}
  paste(text,prefix=''){
   // Remove control sequences, including embedded bracketed-paste terminators.
   const clean=text.replace(/\r\n?/g,'\n').replace(/[\x00-\x08\x0b-\x1f\x7f]/g,'');if(!clean&&!prefix)return;
   if(this.termModes&&this.termModes.flags&32){this.guard(()=>this.controlInput(prefix+'\x1b[200~'+clean+'\x1b[201~'));return;}
   if(!/[\n\t]/.test(clean)){this.guard(()=>this.controlInput(prefix+clean));return;}
   // Live paste without bracketed-paste support needs an explicit review before sending.
   this.cancelPaste();const generation=this.generation,inputGeneration=this.inputGeneration,review=this.pasteReview=make('form','buffered-command'),label=make('label',null,translate('Review paste — sending may run commands')),editor=make('textarea','command-input'),send=button('primary','Send paste'),cancel=button('ghost','Cancel');review.classList.add('paste-review');editor.value=clean;editor.setAttribute('aria-label',translate('Review multiline paste'));send.type='submit';label.append(editor);review.append(label,send,cancel);this.dock.append(review);this.capture.blur();this.stopRepeat();
   let composing=false;this.listen(editor,'compositionstart',()=>composing=true);this.listen(editor,'compositionend',()=>composing=false);this.listen(cancel,'click',()=>{this.cancelPaste();this.focus();});this.listen(review,'submit',e=>{e.preventDefault();if(composing||e.isComposing||send.disabled||review!==this.pasteReview)return;send.disabled=true;const value=editor.value.replace(/\r\n?/g,'\n').replace(/[\x00-\x08\x0b-\x1f\x7f]/g,'');if(generation!==this.generation||inputGeneration!==this.inputGeneration||!this.isVisible()){this.cancelPaste();return;}const bytes=this.termModes&&this.termModes.flags&32?'\x1b[200~'+value+'\x1b[201~':value.replace(/\n/g,'\r');this.cancelPaste();this.guard(()=>this.controlInput(prefix+bytes));});editor.focus();
  }
  cancelPaste(){this.pasteReview?.remove();this.pasteReview=null;}
  // 제어 키는 커서·줄 문맥을 바꾸므로 보낸 뒤 textarea 문맥을 버린다.
  controlInput(bytes){this.resetCapture();return this.input(bytes);}
  focus(){if(!this.disposed&&this.inputActive!==false)(this.inputMode==='direct'?this.capture:this.command).focus({preventScroll:true});}
  // A visible split pane can be inactive: discard old IME/key state without releasing its resize role.
  setInputActive(active){active=!!active;if(this.inputActive===active)return;if(!active){
   // Blur can synchronously commit the IME to its original PTY. Otherwise keep the unsent composition as that pane's editable draft.
   this.capture.blur();if(this.composing){const before=[...this.sent||''],after=[...this.capture.value];let same=0;while(same<before.length&&same<after.length&&before[same]===after[same])same++;const text=after.slice(same).join(''),prefix=this.command.value;this.bufferedVersion=(this.bufferedVersion||0)+1;this.inactiveComposition={prefix,text,version:this.bufferedVersion};this.command.value=prefix+text;this.command.value?drafts.set(this.stateKey,this.command.value):drafts.delete(this.stateKey);this.setInputMode('buffered');}else this.invalidateInput();this.bufferedComposing=false;
  }this.inputActive=active;}
  invalidateInput(){this.inputGeneration++;this.inputArmed=false;this.composing=false;this.cancelPaste();this.resetCapture();this.capture.blur();this.command.blur();this.stopRepeat();this.deferredKeys.splice(0).forEach(p=>p.reject(Error('Input target changed')));}
  // Shift·Ctrl·Alt 토글은 다음 한 번만 적용한다: 글자는 첫 글자에(Shift 대문자·Ctrl 제어 문자·Alt ESC 접두), 키 줄 키는 수정자 변형 시퀀스로 보낸다.
  toggleModifier(name,force){const mods=this.modifiers||={};mods[name]=typeof force==='boolean'?force:!mods[name];if(name==='shift')this.shiftArmed=mods.shift;this.modifierButtons?.[name]?.setAttribute('aria-pressed',String(!!mods[name]));return !!mods[name];}
  toggleShift(force){return this.toggleModifier('shift',force);}
  consumeShift(bytes,isKey=false){const mods={...this.modifiers};if(!mods.shift&&!mods.ctrl&&!mods.alt)return bytes;for(const name of ['shift','ctrl','alt'])if(mods[name])this.toggleModifier(name,false);if(isKey)return encodeKey(bytes,mods);const [first='',...rest]=[...bytes];let head=mods.shift?first.toUpperCase():first;if(mods.ctrl)head=controlChar(head);return (mods.alt?'\x1b':'')+head+rest.join('');}
  sendKey(id){const key=KEYS.find(k=>k.id===id);if(!key)return Promise.reject(Error('Unknown terminal key'));if(this.disposed)return Promise.reject(Error('Input target changed'));const bytes=this.consumeShift(key.bytes,true);if(this.composing)return new Promise((resolve,reject)=>this.deferredKeys.push({bytes,resolve,reject}));return this.controlInput(bytes);}
  bindViewport(){
   // 키보드 높이는 MkKeyboard가 프레임당 한 번 재서 셸을 줄인다. 여기서는 쓰기만 한다(측정·스크롤 보정 없음).
   const viewport=inset=>{if(this.disposed)return;this.keyboardInset=inset;const open=inset>80;if(open&&this.root.dataset.keyboardOpen!=='true')(globalThis.requestAnimationFrame||setTimeout)(()=>this.revealCursor());this.root.dataset.keyboardOpen=String(open);this.dismiss.hidden=!open;this.live.hidden=open||this.inputMode!=='direct';this.queueFit();};
   this.listen(this.abort.signal,'abort',MkKeyboard.subscribe(viewport));MkKeyboard.keepFocus(this.dock,this.abort.signal);this.listen(globalThis,'pagehide',()=>this.disconnect());
   // PTY는 데스크톱과 공유한다. 화면이 가려지면(잠금·앱 전환) 크기 소유를 놓아 데스크톱 크기로 돌리고, 다시 보이면 맞춘다.
   this.listen(globalThis.document||globalThis,'visibilitychange',()=>this.guard(()=>this.syncVisibility()));this.listen(globalThis,'blur',()=>this.stopRepeat());viewport(MkKeyboard.inset());
   if(globalThis.ResizeObserver){this.observer=new ResizeObserver(()=>{if(this.stick)this.scrollBottom();this.queueFit();});this.observer.observe(this.port);}
  }
  setFontScale(scale,notify=true){if(this.disposed)return;this.fontScale=snap(Number(scale)||1);this.fontSize=Math.max(6,Math.round(13*this.fontScale));this.cellWidth=8*this.fontSize/13;this.cellHeight=18*this.fontSize/13;this.historyElement.style.fontSize=`${this.fontSize}px`;this.historyElement.style.lineHeight=`${this.cellHeight}px`;
   // 히스토리 <pre>도 캔버스와 같은 글꼴·셀 폭으로 맞춘다. 폭이 다르면 위로 스크롤할 때 열이 좌우로 어긋나 보인다.
   this.historyElement.style.fontFamily=FAMILY;this.historyElement.style.fontWeight='300';this.ctx.font=`300 ${this.fontSize}px ${FAMILY}`;this.font=null;const glyph=this.ctx.measureText?.('M')?.width,wide=this.ctx.measureText?.('한')?.width;if(glyph>0)this.historyElement.style.letterSpacing=`${this.cellWidth-glyph}px`;if(wide>0)this.historyElement.style.setProperty('--wide-spacing',`${2*this.cellWidth-wide}px`);this.schedule(true);if(notify)this.options.onPreferenceChange?.({textScale:this.fontScale});this.queueFit();}
  // 키보드 애니메이션·주소창 접힘·회전은 이벤트가 연달아 온다. 멈춘 뒤 한 번만 맞춰 행 수가 출렁이지 않게 한다.
  isVisible(){return this.visible&&globalThis.document?.visibilityState!=='hidden';}
  setVisible(visible){if(this.disposed)return Promise.resolve();this.visible=!!visible;return this.syncVisibility();}
  async syncVisibility(){const visible=this.isVisible(),version=this.visibilityVersion=(this.visibilityVersion||0)+1;clearTimeout(this.fitTimer);if(!visible){this.invalidateInput();clearTimeout(this.labelTimer);this.labelTimer=null;if(this.rafId)(globalThis.cancelAnimationFrame||clearTimeout)(this.rafId);this.rafId=0;this.full=true;}else this.schedule(true);if(!this.ready)return;if(this.resizePending)await this.resizePending.catch(()=>{});if(this.disposed||!this.ready||version!==this.visibilityVersion)return;if(!visible){await this.role(Uint8Array.from([0,2,0]));return;}if(this.autoFit&&!this.fit)await this.fitToPhone(true,false);else if(this.fit)await this.resize(true);}
  queueFit(){clearTimeout(this.fitTimer);if(!this.isVisible()||!this.fit||!this.ready||this.fitPending)return;this.fitTimer=setTimeout(()=>{if(this.resizePending)return this.queueFit();if(this.isVisible()&&this.fit&&this.ready&&!this.fitPending&&!this.disposed)this.guard(()=>this.resize());},150);}
  // 스크롤 이벤트는 정확히 바닥(1px 미만)일 때만 바닥 따라가기로 돌린다. 한 줄 여유를 주면 위로 막 끌기 시작한 손가락이 따라가기로 되돌아가, 그때 온 히스토리 응답이 화면을 바닥으로 끌어내린다.
  atBottom(slack=this.cellHeight||18){const p=this.port;return !this.historyWindowed&&p.scrollHeight-p.scrollTop-p.clientHeight<slack;}
  returnToLive(){if(this.historyWindowed){this.resetHistory();this.guard(()=>this.loadHistory());}this.scrollBottom();}
  scrollBottom(){this.port.scrollTop=this.port.scrollHeight;this.stick=true;this.latestButton.hidden=true;}
  async open(){
   const generation=this.generation;let result;try{result=await this.options.connect({sessionId:this.session});}catch(e){if(generation===this.generation)this.disconnect('disconnected',e.message);return;}
   const {socket,credentials,channel:warmChannel,messages}=result||{};if(this.disposed||generation!==this.generation){socket?.close();return;}if(!socket||!credentials){this.error(Error('Invalid terminal connection factory'));return;}
   if(socket.readyState===2||socket.readyState===3||socket.closed){this.disconnect('disconnected','Disconnected');return;}
   this.socket=socket;this.connectionTimer=setTimeout(()=>{if(generation===this.generation)this.disconnect('disconnected','Terminal connection timed out');},15000);socket.binaryType='arraybuffer';let phase=warmChannel?1:0,channel=warmChannel;
   // 미리 연 터미널 소켓(client.js warmTerminal)은 인증·Hello까지 끝나 있다. 그 사이 받은 메시지를 이어서 처리한다.
   const onMessage=e=>{if(generation!==this.generation||this.disposed)return;try{
    if(phase===0){const challenge=JSON.parse(e.data),nonce=crypto.getRandomValues(new Uint8Array(32));if(challenge.version!==2)throw Error('Unsupported terminal protocol');channel=new C.Channel(C.sha256(C.unhex(credentials.credential)),C.concat(C.unhex(challenge.challenge),nonce));this.channel=channel;socket.send(JSON.stringify({device_id:credentials.device_id,token:null,client_nonce:C.hex(nonce)}));socket.send(channel.seal(C.enc.encode('{"label":"Live terminal"}')));
     // 게이트웨이는 proof만 읽고 나머지를 IPC로 넘긴다(협상은 교집합). ServerHello를 기다리지 않고 Hello·role·attach를 함께 보낸다.
     this.send(2,C.concat(T.v(1),T.v(1),T.v((1n<<56n)|1n|4n|4096n|8192n),T.v(0),T.text('krill-mobile-grid')));this.guard(()=>this.role(Uint8Array.from([0,2,0])));this.send(0x10,C.concat(T.v(this.session),Uint8Array.from([0,0])));this.prefit();phase=1;return;}
    const bytes=channel.open(e.data);if(phase===1){JSON.parse(new TextDecoder().decode(bytes));phase=2;return;}
    if(phase===2){if(bytes[4]!==1)throw Error('Unexpected terminal handshake');const hello=T.reader(bytes.slice(5));hello.n();hello.n();this.modesSupported=!!(hello.u()&8192n);phase=3;return;}
    if(bytes.length<5||new DataView(bytes.buffer,bytes.byteOffset).getUint32(0,true)!==bytes.length-4)throw Error('Invalid screen frame');const body=bytes.slice(5),r=T.reader(body);
    switch(bytes[4]){
     case 0x20:this.attached={seq:r.u(),revision:r.u()};break;
     case 0x21:{try{const result=T.update(body,this.model);for(const y of result.dirty)this.dirty.add(y);if(result.done){this.historyVersion=(this.historyVersion||0)+1;clearTimeout(this.connectionTimer);const first=!this.ready;this.ready=true;if(first&&this.isVisible()&&this.port.clientHeight)this.guard(()=>this.loadHistory());if(first&&this.autoFit&&!this.fit&&this.isVisible())this.guard(()=>this.fitToPhone(true,false));this.schedule();if(uncertainInputs.has(this.stateKey)){this.recoverButton.hidden=false;this.status('ready','Input delivery is uncertain; input will not be resent.');}else if(!this.contextBlocked)this.status('ready',`${this.model.cols} × ${this.model.lines}`);if(this.model.title!==this.title){this.title=this.model.title;this.options.onTitle?.(this.title||'');}}}catch(error){this.send(0x11);throw error;}break;}
     case 0x26:this.receiveHistory(T.history(body));break;
     case 0x27:{const id=r.n(),result=r.n(2),pending=this.pendingInputs.get(id);if(!pending)break;this.pendingInputs.delete(id);clearTimeout(pending.timer);clearTimeout(pending.slowTimer);if(result){this.inputWaiting=false;const error=Error('Terminal input rejected. Resume input, then re-enter rejected text; it will not be resent.');this.contextBlocked=true;this.invalidateInput();this.recoverButton.hidden=false;pending.reject(error);this.error(error);}else{pending.resolve();if(!this.pendingInputs.size){this.inputWaiting=false;if(!this.contextBlocked)this.status('ready',`${this.model.cols} × ${this.model.lines}`);}}break;}
     case 0x2b:{if(!this.modesSupported)break;this.termModes={kitty:r.byte(),flags:r.n(65535)};r.end();break;}
     case 0x2c:{const result=r.n(3),pending=this.pendingRoles.shift();if(pending){clearTimeout(pending.timer);if(result)pending.reject(Error('Terminal resize rejected'));else pending.resolve();}else if(result)throw Error('Terminal role rejected');break;}
     case 0x24:this.disconnect('ended','Session ended');break;
     case 0x25:this.disconnect('error','Session unavailable');break;
    }
   }catch(error){this.error(error);if(phase<3)socket.close();}};
   this.listen(socket,'message',onMessage);
   this.listen(socket,'close',e=>{if(generation===this.generation)this.disconnect(e.code===1008?'denied':'disconnected',e.code===1008?'Terminal authentication rejected':'Disconnected');});this.listen(socket,'error',()=>{if(generation===this.generation)this.disconnect('disconnected','Live terminal connection failed');});
   try{
    if(warmChannel){this.channel=warmChannel;this.guard(()=>this.role(Uint8Array.from([0,2,0])));this.send(0x10,C.concat(T.v(this.session),Uint8Array.from([0,0])));this.prefit();}
    if(Array.isArray(messages))for(const data of messages.splice(0))onMessage({data});
   }catch(error){this.error(error);if(phase<3)socket.close();}
  }
  send(kind,body){if(!this.socket||this.socket.readyState!==1||!this.channel)throw Error('Terminal disconnected');this.socket.send(this.channel.seal(T.frame(kind,body)));}
  // 키보드가 열리거나 입력을 보내면 커서 행이 보이게 세로로만 옮긴다. 가로 위치(scrollLeft)는 사용자가 둔 곳을 유지한다.
  revealCursor(){const c=this.model.cursor,p=this.port;if(this.disposed||!c?.visible)return;const top=(this.canvas.offsetTop||0)+c.line*this.cellHeight,bottom=top+this.cellHeight;if(top<p.scrollTop)p.scrollTop=top;else if(bottom>p.scrollTop+p.clientHeight)p.scrollTop=bottom-p.clientHeight;}
  input(text){if(this.disposed||!this.ready)return Promise.reject(Error('Wait for the live terminal to connect'));if(this.inputActive===false||!this.isVisible()||this.contextBlocked||this.pasteReview)return Promise.reject(Error('Resume terminal input before sending'));if(this.historyWindowed)this.returnToLive();this.revealCursor();const bytes=C.enc.encode(text),id=++this.inputId;if(bytes.length>65536)return Promise.reject(Error('Input is too large (maximum 64 KiB)'));return new Promise((resolve,reject)=>{const pending={resolve,reject,slowTimer:setTimeout(()=>{if(this.pendingInputs.has(id)&&!this.contextBlocked){this.inputWaiting=true;this.status('ready','Waiting for input confirmation…');}},1000),timer:setTimeout(()=>{if(this.pendingInputs.has(id))this.disconnect('disconnected','Input confirmation timed out');},10000)};this.pendingInputs.set(id,pending);try{this.send(0x13,C.concat(T.v(id),T.v(bytes.length),bytes));}catch(e){this.pendingInputs.delete(id);clearTimeout(pending.timer);clearTimeout(pending.slowTimer);this.contextBlocked=true;this.invalidateInput();this.recoverButton.hidden=false;reject(e);}});}
  role(body){return new Promise((resolve,reject)=>{const pending={resolve,reject,timer:setTimeout(()=>{this.socket?.close();this.disconnect('disconnected','Terminal resize timed out');},5000)};this.pendingRoles.push(pending);try{this.send(0x17,body);}catch(e){this.pendingRoles.pop();clearTimeout(pending.timer);reject(e);}});}
  async fitToPhone(enabled=!this.fit,save=true){if(!this.ready)throw Error('Wait for the live terminal to connect');if(this.fitPending||enabled===this.fit)return;const generation=this.generation;this.fitPending=true;this.fitButton.disabled=true;try{if(enabled)await this.resize(true);else await this.role(Uint8Array.from([0,2,0]));if(this.disposed||generation!==this.generation)return;this.fit=enabled;this.root.dataset.fit=String(enabled);this.fitButton.setAttribute('aria-pressed',String(enabled));this.fitButton.replaceChildren(icon(enabled?'smartphone':'monitor'));if(enabled)this.port.scrollLeft=0;if(save){this.autoFit=enabled;this.options.onPreferenceChange?.({fitToPhone:enabled});}if(!this.contextBlocked)this.status('ready',`${this.model.cols} × ${this.model.lines}`);}finally{this.fitPending=false;this.fitButton.disabled=false;this.queueFit();}}
  // 키보드가 열려 줄어든 높이로는 행을 바꾸지 않는다(열 때마다 PTY가 줄었다 늘며 TUI가 다시 그려져 흔들린다). 그동안은 스크롤로 커서를 보인다.
  fitSize(){const p=this.port;if(!p.clientWidth)return null;const keyboard=this.root.dataset.keyboardOpen==='true',rowsFor=n=>Math.max(10,Math.min(200,Math.floor(n/this.cellHeight))),cols=Math.max(10,Math.min(2048,Math.floor((p.clientWidth-2)/this.cellWidth))),rows=!p.clientHeight?this.model.lines:keyboard?this.fitRows??rowsFor(p.clientHeight+(this.keyboardInset||0)):(this.fitRows=rowsFor(p.clientHeight));return {cols,rows};}
  async resize(force=false){if(!this.isVisible())return;const size=this.fitSize();if(!size)return;const {cols,rows}=size;if(this.resizePending)return this.resizePending;if(!force&&cols===this.model.cols&&rows===this.model.lines)return;this.resizePending=this.role(C.concat(T.v(1),T.v(cols),T.v(rows)));try{await this.resizePending;}finally{this.resizePending=null;}}
  // 자동 Fit이면 크기 요청을 attach와 함께 보낸다. 첫 화면을 받은 뒤 보내면 왕복이 한 번 더 든다. 첫 화면 뒤 fitToPhone은 이 응답을 기다린다(resizePending).
  prefit(){if(!this.isVisible()||!this.autoFit||this.fit||this.resizePending||!this.port.clientHeight)return;const size=this.fitSize();if(!size)return;const pending=this.role(C.concat(T.v(1),T.v(size.cols),T.v(size.rows))),clear=()=>{if(this.resizePending===pending)this.resizePending=null;};pending.then(clear,clear);this.resizePending=pending;}
  historyThreshold(){return Math.max(this.cellHeight*6,(this.port.clientHeight||0)*3,Math.min((this.port.clientHeight||this.cellHeight)*6,(this.historyVelocity||0)*Math.max(250,(this.historyRtt||0)*2)));}
  warmHistory(){if(this.historyWarmTimer||!this.isVisible()||!this.port.clientHeight||!this.stick||this.historyEnd||this.historyWindowed||this.historyRows.length>=900)return;this.historyWarmTimer=setTimeout(()=>{this.historyWarmTimer=null;if(this.stick&&this.isVisible()&&!this.historyWindowed&&this.historyRows.length<900)this.guard(()=>this.loadHistory(false,false,Math.min(300,900-this.historyRows.length)));},0);}
  resetHistory(){clearTimeout(this.historyWarmTimer);this.historyWarmTimer=null;this.historySource=null;this.historySkip=0;this.historyPending=null;this.historyRows=[];this.historyEnd=false;this.historyWindowed=false;this.historyReplacing=false;this.historyLoadedVersion=-1;this.canvas.hidden=false;this.historyElement.textContent='';this.historyControls.hidden=true;}
  // A fresh upward gesture from live output reloads hot history; an empty initial
  // snapshot must not permanently disable history produced later in the session.
  loadHistory(reveal=false,refresh=false,count=300){
   if(!this.ready||this.historyPending||this.disposed)return;
   refresh=refresh||this.historyEnd&&!this.historyRows.length&&this.historyLoadedVersion!==(this.historyVersion||0);
   if(this.historyEnd&&!refresh)return;
   // 자동 첫 로드(새 세션 포함)는 받은 행이 생길 때까지 줄을 숨겨, 빈 기록에 '불러오는 중' 줄이 잠깐 끼었다 빠지며 터미널을 밀지 않게 한다.
   this.historyReveal=reveal===true;if(this.historyReveal||this.historyRows.length)this.historyControls.hidden=false;
   // 새로고침은 이미 받은 행 수만큼 받아 캔버스 위 높이를 그대로 둔다. 손가락·관성 스크롤 중 scrollTop을 고치면 관성이 끊긴다.
   if(refresh){this.historyReplacing=true;count=Math.min(1000,Math.max(count,this.historyRows.length));}const req=++this.historyId,source=refresh?null:this.historySource,skip=refresh?0:this.historySkip;
   this.historyPending={req,source,skip,refresh,replace:this.historyReplacing,started:globalThis.performance?.now?.()??Date.now(),version:this.historyVersion||0};this.historyButton.disabled=true;this.historyStatus.textContent=translate('Loading earlier output…');
   this.send(0x12,C.concat(T.v(req),source===null?T.v(0):C.concat(T.v(1),T.v(source)),T.v(skip),T.v(count)));
  }
  // 2칸 글자(한글 등)는 글꼴 폭이 'M' 두 개와 달라 연속 구간을 span으로 묶고 2칸에 맞춘 자간을 준다. 안 그러면 히스토리 열이 캔버스와 어긋난다.
  // ponytail: 2칸 폭은 '한' 한 글자로 잰다. 이모지처럼 폭이 다른 2칸 글자는 조금 어긋날 수 있다.
  historyRow(row){const out=[];let run='',wide=false;const flush=()=>{if(!run)return;if(wide){const span=make('span',null,run);span.style.letterSpacing='var(--wide-spacing)';out.push(span);}else out.push(run);run='';};for(const c of row){if(c.flags&16)continue;const w=!!(c.flags&8)&&!(c.flags&256);if(w!==wide)flush();wide=w;run+=(c.flags&256)?' ':c.text;}flush();return out;}
  receiveHistory(reply){
   const pending=this.historyPending;if(!pending||reply.req!==pending.req)return;this.historyPending=null;this.historyRtt=(globalThis.performance?.now?.()??Date.now())-pending.started;this.historyLoadedVersion=pending.version;this.historySkip=reply.skip+reply.rows.length;
   if(this.historySkip>=reply.total||!reply.rows.length){this.historySource=pending.source===null?reply.pages-1:pending.source-1;this.historySkip=0;this.historyEnd=this.historySource<0;}else{this.historySource=pending.source;this.historyEnd=false;}
   // Empty hot/cold pages must not flash a blank view while the next page loads.
   if(!reply.rows.length&&!this.historyEnd)return this.loadHistory(this.historyReveal);
   this.historyReplacing=false;
   const reveal=this.historyReveal,following=this.stick,before=this.canvas.offsetTop??this.port.scrollHeight,anchor=this.historyElement.children[0]?.getBoundingClientRect?.().top,oldRows=pending.replace?[]:this.historyRows,combined=[...reply.rows,...oldRows];
   // Keep a bounded window while continuing into older cold pages. Returning to
   // live output restores the canvas instead of joining discontiguous rows.
   this.historyWindowed=(!pending.replace&&this.historyWindowed)||combined.length>1000;this.historyRows=combined.slice(0,1000);this.historyControls.hidden=!this.historyRows.length;this.canvas.hidden=this.historyWindowed;if(this.historyWindowed)this.stick=false;
   const added=reply.rows.map(row=>{const line=make('span','terminal-history-row');line.append(...this.historyRow(row),'\n');return line;});
   // Already-visible rows keep their DOM, selection and layout. Only new rows are built.
   if(pending.replace)this.historyElement.replaceChildren(...added);else this.historyElement.prepend(...added);
   while(this.historyElement.children.length>1000)this.historyElement.children[this.historyElement.children.length-1].remove();
   if(following&&!this.historyReveal&&!this.historyWindowed)this.scrollBottom();else{const moved=!pending.replace&&anchor!=null?this.historyElement.children[reply.rows.length]?.getBoundingClientRect?.().top-anchor:null,delta=moved??(this.historyWindowed?reply.rows.length*this.cellHeight:(this.canvas.offsetTop??this.port.scrollHeight)-before);if(delta)this.port.scrollTop+=delta;}
   this.historyButton.disabled=this.historyEnd;this.historyStatus.textContent=translate(this.historyEnd?'Beginning of saved output':'Scroll up for earlier output');
   if(this.historyReveal){this.historyReveal=false;this.port.scrollTop=0;this.stick=false;}
   this.latestButton.hidden=this.stick&&!this.historyWindowed;
   // A hot refresh can return the same rows after a resize. Continue the upward
   // request when already at the top; native scrolling cannot fire again at zero.
   if(!reveal&&!this.stick&&!this.historyEnd&&this.port.scrollTop<this.historyThreshold())this.guard(()=>this.loadHistory());else this.warmHistory();
  }
  // 갱신은 dirty 행으로 모아 프레임당 한 번 그린다. 크기·배율이 바뀌거나 full이면 전체, 아니면 dirty 행(+커서 이동 전후 행)만.
  schedule(full=false){if(full)this.full=true;if(this.rafId||this.disposed||!this.isVisible())return;const raf=globalThis.requestAnimationFrame||(fn=>setTimeout(fn,16));this.rafId=raf(()=>{this.rafId=0;if(!this.disposed)this.draw();});}
  draw(){
   if(this.disposed||!this.isVisible()){this.full=true;return;}
   const m=this.model,ctx=this.ctx,w=this.cellWidth||8,h=this.cellHeight||18,font=this.fontSize||13,cssW=m.cols*w,cssH=m.lines*h;
   // iOS 캔버스 면적 한도(약 16.7M px, 추정) 아래로 배율을 묶는다.
   const scale=Math.min(globalThis.devicePixelRatio||1,Math.sqrt(16e6/(cssW*cssH))),width=Math.round(cssW*scale),height=Math.round(cssH*scale);
   let full=this.full||this.canvas.width!==width||this.canvas.height!==height;this.full=false;
   if(this.canvas.width!==width||this.canvas.height!==height){this.canvas.width=width;this.canvas.height=height;this.font=null;}
   if(this.cssSize!==`${cssW}x${cssH}`){this.cssSize=`${cssW}x${cssH}`;this.canvas.style.width=`${cssW}px`;this.canvas.style.height=`${cssH}px`;if(this.stick)this.scrollBottom();}
   ctx.setTransform(scale,0,0,scale,0,0);ctx.textBaseline='top';
   const cursor=m.cursor?.visible?{line:m.cursor.line,column:m.cursor.column,shape:m.cursorStyle?.shape??2}:null,cursorKey=JSON.stringify(cursor),dirty=this.dirty;this.dirty=new Set();
   if(cursorKey!==this.cursorKey){if(this.cursorLine!=null)dirty.add(this.cursorLine);if(cursor)dirty.add(cursor.line);}this.cursorKey=cursorKey;this.cursorLine=cursor?.line;
   const palette=['#15161e','#f7768e','#9ece6a','#e0af68','#7aa2f7','#bb9af7','#7dcfff','#a9b1d6','#414868','#f7768e','#9ece6a','#e0af68','#7aa2f7','#bb9af7','#7dcfff','#c0caf5'];
   const color=(c,fallback)=>{if(c==null)return fallback;if(typeof c==='string')return c;const n=c.index;if(n<16)return palette[n];if(n>=232){const g=8+(n-232)*10;return `rgb(${g},${g},${g})`;}const k=n-16,levels=[0,95,135,175,215,255];return `rgb(${levels[Math.floor(k/36)]},${levels[Math.floor(k/6)%6]},${levels[k%6]})`;};
   ctx.fillStyle='#1a1b26';if(full)ctx.fillRect(0,0,cssW,cssH);else for(const y of dirty)if(y<m.lines)ctx.fillRect(0,y*h,cssW,h);
   for(let y=0;y<m.lines;y++){if(!full&&!dirty.has(y))continue;for(let x=0;x<(m.rows[y]?.length||0);x++){const c=m.rows[y][x],f=c.flags;if(f&16)continue;const width=f&8?w*2:w;let fg=color(c.fg,'#c0caf5'),bg=color(c.bg,'#1a1b26');if(f&4)[fg,bg]=[bg,fg];ctx.fillStyle=bg;ctx.fillRect(x*w,y*h,width,h);if(f&256)continue;ctx.fillStyle=fg;ctx.globalAlpha=f&128?.65:1;const face=`${f&2?'italic ':''}${f&1?'500':'300'} ${font}px ${FAMILY}`;if(face!==this.font){ctx.font=face;this.font=face;}ctx.fillText(c.text,x*w,y*h+font/13,width);if(f&32){ctx.fillStyle=color(c.underline,fg);ctx.fillRect(x*w,y*h+h-3*font/13,width,font/13);}if(f&64)ctx.fillRect(x*w,y*h+h/2,width,font/13);ctx.globalAlpha=1;}}
   if(cursor&&(full||dirty.has(cursor.line))){ctx.fillStyle='#c0caf5';const x=cursor.column*w,y=cursor.line*h;if(cursor.shape===2)ctx.fillRect(x,y,Math.max(1,font/13),h);else if(cursor.shape===1)ctx.fillRect(x,y+h-2,w,2);else{ctx.strokeStyle='#c0caf5';ctx.strokeRect(x+.5,y+.5,w-1,h-1);}}
   // 화면 전체 텍스트를 매 프레임 만들지 않도록 접근성 라벨은 최대 500ms마다 갱신한다.
   this.labelTimer??=setTimeout(()=>{this.labelTimer=null;if(!this.disposed&&this.isVisible())this.canvas.setAttribute('aria-label',this.screenText());},500);
  }
  screenText(){return this.model.rows.map(row=>row.filter(c=>!(c.flags&16)).map(c=>(c.flags&256)?' ':c.text).join('')).join('\n');}
  text(){return (this.historyElement.textContent+this.screenText()).replace(/[ \t]+$/gm,'').replace(/\n+$/,'');}
  disconnect(phase='disconnected',message='Disconnected'){
   clearTimeout(this.connectionTimer);clearTimeout(this.fitTimer);clearTimeout(this.historyWarmTimer);this.historyWarmTimer=null;this.generation++;this.ready=false;this.inputWaiting=false;this.fit=false;this.termModes=null;this.modesSupported=false;this.recoverButton.hidden=true;delete this.root.dataset.fit;this.wasTyping=[this.capture,this.command].includes(globalThis.document?.activeElement);this.invalidateInput();const uncertain=this.pendingInputs.size,error=Error('Input delivery is uncertain; input will not be resent.');if(uncertain){uncertainInputs.add(this.stateKey);this.contextBlocked=true;}for(const pending of this.pendingInputs.values()){clearTimeout(pending.timer);clearTimeout(pending.slowTimer);pending.reject(error);}this.pendingInputs.clear();for(const pending of this.pendingRoles.splice(0)){clearTimeout(pending.timer);pending.reject(Error('Terminal disconnected'));}this.channel=null;this.socket?.close();this.fitButton.setAttribute('aria-pressed','false');this.fitButton.replaceChildren(icon('monitor'));this.status(phase,uncertain?error.message:message,uncertain?error:undefined);
  }
  unmount(){if(this.disposed)return;instances.delete(this);this.command.value?drafts.set(this.stateKey,this.command.value):drafts.delete(this.stateKey);this.disconnect();this.disposed=true;this.abort.abort();this.observer?.disconnect();clearTimeout(this.labelTimer);if(this.rafId)(globalThis.cancelAnimationFrame||clearTimeout)(this.rafId);this.frame.remove();this.dock.remove();this.root.classList.remove('terminal-mount');this.root.style.removeProperty('--keyboard-inset');delete this.root.dataset.keyboardOpen;delete this.root.dataset.inputMode;delete this.root.dataset.phase;delete this.root.dataset.fit;}
 }
 const mobile=globalThis.KrillMobile||(globalThis.KrillMobile={});
 mobile.terminal=Object.freeze({keys:KEYS,fontScales:SCALES,
  updateBusy(scope=''){return [...uncertainInputs].some(key=>String(key).startsWith(scope))||[...instances].some(i=>String(i.stateKey).startsWith(scope)&&(i.composing||i.bufferedComposing||i.bufferedPending||i.pendingInputs.size||i.pendingRoles.length||i.deferredKeys.length||i.heldPointer!=null||i.pasteReview||i.contextBlocked||i.sent||i.historyRows.length&&!i.atBottom()));},
  snapshotDrafts(){const saved=new Map(drafts);for(const i of instances){if(i.command.value)saved.set(i.stateKey,i.command.value);else saved.delete(i.stateKey);}return [...saved];},
  restoreDrafts(entries){for(const [key,value] of entries)if(typeof key==='string'&&typeof value==='string'&&value)drafts.set(key,value);},
  mount(root,options){const instance=new Terminal(root,options);instances.add(instance);return Object.freeze(Object.fromEntries(['unmount','focus','setInputActive','setVisible','setFontScale','setInputMode','getInputMode','sendKey','toggleShift','fitToPhone','loadHistory','text'].map(name=>[name,instance[name].bind(instance)])));}});
})();

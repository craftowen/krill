// Orca mobile UI reference: MIT, Copyright (c) 2026 Lovecast Inc.
// MIT notice: docs/research/orca-mobile-ui-spec.md §5.1. Lucide icon paths: ISC.
(() => {
  const M = globalThis.KrillMobile,
    endpoint = M.transport.bootstrap(),
    parameters = endpoint.parameters;
  let pairing = endpoint.pair,
    credentials = endpoint.credentials,
    preferences;
  try {
    preferences = JSON.parse(
      localStorage.getItem("krill-mobile-ui-v1") || "{}",
    );
  } catch {
    preferences = {};
  }
  const state = (M.store = {
    snapshot: null,
    connection: { phase: "idle", message: "Not connected" },
    groups: new Map(),
    sessions: new Map(),
    expected: new Map(),
    drafts: new Map(),
    ui: { search: "", filter: "all" },
    preferences: preferences || {},
    lastSession: M.recentSession.read(credentials?.device_id),
    logs: [],
  });
  let pool = null,
    transport,
    landing = false,
    activeView = null,
    entryDrawPending = false;
  const hostViews = new Map();
  const root = document.getElementById("route-root"),
    banner = document.getElementById("connection-banner"),
    notice = document.getElementById("notice"),
    dialog = document.getElementById("action-sheet"),
    sheetBody = document.getElementById("sheet-content");
  let activeRouteScreen = "home",
    screen,
    abort,
    routeKey,
    lastFocus,
    lastTrigger,
    deepLink = parameters.get("session");
  const t = (text, ...args) => M.i18n?.t(text, ...args) || text;
  const el = (tag, text, cls) => {
    const node = document.createElement(tag);
    if (text !== undefined) node.textContent = text;
    if (cls) node.className = cls;
    return node;
  };
  const paths = {
    back: "m15 18-6-6 6-6",
    chevronRight: "m9 18 6-6-6-6",
    chevronDown: "m6 9 6 6 6-6",
    plus: "M12 5v14M5 12h14",
    terminal: "m4 7 5 5-5 5M12 17h8",
    columns:
      "M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2ZM12 3v18",
    rows: "M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2ZM3 12h18",
    panelLeft:
      "M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2ZM9 3v18",
    monitor: "M3 3h18v14H3zM8 21h8M12 17v4",
    more: "M5 12h.01M12 12h.01M19 12h.01",
    edit: "M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z",
    trash:
      "M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",
    search: "m21 21-4.3-4.3M19 11a8 8 0 1 1-16 0 8 8 0 0 1 16 0",
    settings:
      "M9 3h6l1 4 4 1v8l-4 1-1 4H9l-1-4-4-1V8l4-1zM15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0",
    accounts:
      "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M13 3a4 4 0 1 1 0 8M20 21v-2a4 4 0 0 0-3-3.9M13 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0",
    tasks: "M9 6h11M9 12h11M9 18h11m-16-12 1 1 2-2m-3 7 1 1 2-2m-3 7 1 1 2-2",
    filter: "M4 6h16M7 12h10M10 18h4",
    git: "M6 3v12a6 6 0 0 0 12 0V9M9 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0M21 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0",
    file: "M14 2H6v20h12V6zM14 2v6h6",
    info: "M12 11v6M12 7h.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0",
    activity: "M2 12h4l3-9 6 18 3-9h4",
    close: "M18 6 6 18M6 6l12 12",
    share: "M4 12v8h16v-8M16 6l-4-4-4 4M12 2v13",
    scan: "M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2M7 12h10",
    download: "M12 3v12m-5-5 5 5 5-5M5 21h14",
    copy: "M10 9h9a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1h-9a1 1 0 0 1-1-1v-9a1 1 0 0 1 1-1zM5 15H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h9a1 1 0 0 1 1 1",
    check: "M20 6 9 17l-5-5",
    arrowUp: "M12 19V5m-7 7 7-7 7 7",
  };
  function icon(name) {
    const s = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    s.setAttribute("viewBox", "0 0 24 24");
    s.setAttribute("fill", "none");
    s.setAttribute("stroke", "currentColor");
    s.setAttribute("stroke-width", "1.8");
    s.setAttribute("stroke-linecap", "round");
    s.setAttribute("stroke-linejoin", "round");
    s.setAttribute("aria-hidden", "true");
    const p = document.createElementNS(s.namespaceURI, "path");
    p.setAttribute("d", paths[name] || paths.terminal);
    s.append(p);
    return s;
  }

  let noticeTimer, sheetNotice;
  const hideNotice = () => {
      clearTimeout(noticeTimer);
      noticeTimer = null;
      notice.hidden = true;
      if (sheetNotice) sheetNotice.hidden = true;
    },
    toast = (message, ms = 5000) => {
      const text = t(message);
      if (notice.hidden || notice.textContent !== text)
        notice.textContent = text;
      notice.hidden = false;
      if (dialog.open && sheetBody) {
        if (!sheetNotice?.isConnected) {
          sheetNotice = el("div", undefined, "sheet-notice");
          sheetNotice.setAttribute("role", "alert");
          sheetNotice.addEventListener("click", hideNotice);
          sheetBody.insertBefore(sheetNotice, sheetBody.children[2] || null);
        }
        sheetNotice.textContent = text;
        sheetNotice.hidden = false;
      }
      clearTimeout(noticeTimer);
      noticeTimer = setTimeout(hideNotice, ms);
    },
    error = (e) => toast(e?.message || String(e));
  notice.addEventListener("click", hideNotice);
  let hostGeneration = 0,
    productPending = 0;
  async function act(action) {
    productPending++;
    try {
      await action();
    } catch (e) {
      error(e);
    } finally {
      productPending--;
    }
  }
  const sessionScope = () =>
    JSON.stringify([
      endpoint.profiles().find((h) => h.active)?.id || location.origin,
      credentials?.device_id,
    ]);
  const sessionKey = (id) => sessionScope() + "\n" + id;

  function scopePreferences() {
    if (endpoint.profiles().length !== 1 || !credentials) return;
    for (const kind of ["sessionViewModes", "terminalInputModes"]) {
      const values = state.preferences[kind];
      if (!values) continue;
      for (const [id, value] of Object.entries(values))
        if (/^[1-9][0-9]*$/.test(id)) {
          values[sessionKey(id)] ??= value;
          delete values[id];
        }
    }
  }
  scopePreferences();
  function button(label, action, cls = "", glyph) {
    const b = el("button", glyph ? undefined : label, cls);
    b.type = "button";
    b.setAttribute("aria-label", label);
    if (glyph) {
      b.dataset.focusKey = `${glyph}:${label}`;
      b.append(icon(glyph));
      if (
        !cls.includes("icon-button") &&
        !cls.includes("tab-add") &&
        !cls.includes("new-workspace-fab")
      )
        b.append(el("span", label));
    }
    b.addEventListener("click", (e) => {
      lastTrigger = b;
      return act(() => action(e));
    });
    return b;
  }
  let routeStack = [location.hash || "#/"],
    historyBack = false;
  const hostRoute = () =>
    "/host/" +
    encodeURIComponent(
      endpoint.profiles().find((h) => h.active)?.id || "local",
    );

  const sessionPath = (p) => /^\/host\/[^/]+\/group\//.test(p);
  const go = (path, replace = false) => {
    path = path.replace(/^\/host\/local(?=\/|$)/, hostRoute());
    pendingRecent = null;
    const hash = "#" + path;
    if (!replace && sessionPath(path) && sessionPath(location.hash.slice(1)))
      replace = true;
    if (replace) {
      routeStack[routeStack.length - 1] = hash;
      history.replaceState({}, "", location.pathname + location.search + hash);
      render();
    } else if (location.hash !== hash) location.hash = hash;
  };
  function back(fallback = "/") {
    if (routeStack.length > 1) {
      historyBack = true;
      history.back();
    } else go(fallback, true);
  }
  function backTo(path) {
    path = path.replace(/^\/host\/local(?=\/|$)/, hostRoute());
    if (routeStack.at(-2) === "#" + path) {
      historyBack = true;
      history.back();
    } else go(path, true);
  }
  const dot = (status) => {
    const d = el(
      "span",
      undefined,
      `status-dot ${String(status).toLowerCase()}`,
    );
    d.setAttribute("aria-label", status);
    d.setAttribute("role", "img");
    return d;
  };
  const rollup = (sessions) => {
    const values = sessions.map((s) => (s.exited ? "Exited" : s.state));
    return (
      ["Waiting", "Blocked", "Working", "Done", "Exited", "Unknown"].find((s) =>
        values.includes(s),
      ) || "Unknown"
    );
  };
  const groupRoute = (g, id) => {
    const session = id || g?.sessions[0]?.id;
    return g && session
      ? `${hostRoute()}/group/${encodeURIComponent(g.key)}/s/${session}`
      : hostRoute();
  };
  function header(title, fallback, onBack = () => back(fallback)) {
    const h = el("header", undefined, "page-header");
    h.append(button(t("Back"), onBack, "icon-button", "back"));
    const copy = el("div", undefined, "header-copy");
    copy.append(
      el(
        "h1",
        activeRouteScreen === "session" || activeRouteScreen === "workspaces"
          ? title
          : t(title),
      ),
    );
    h.append(copy);
    return h;
  }
  function linkRow(title, description, path, glyph) {
    const row = button("", () => go(path), "setting-link");
    row.setAttribute("aria-label", t(title));
    row.append(icon(glyph));
    const copy = el("span", undefined, "link-copy");
    copy.append(el("strong", t(title)));
    if (description) copy.append(el("small", t(description)));
    row.append(copy, icon("chevronRight"));
    return row;
  }

  function restoreFocus() {
    const focus = lastFocus;
    lastFocus = null;
    lastTrigger = null;
    document.body.classList.remove("sheet-open");
    focus?.isConnected && focus.focus({ preventScroll: true });
  }
  function closeSheet() {
    if (dialog.open) dialog.close();
    restoreFocus();
    sheetBody.replaceChildren();
  }
  dialog.addEventListener("close", () => {
    if (!dialog.open) {
      restoreFocus();
      sheetBody.replaceChildren();
    }
  });
  dialog.addEventListener("click", (e) => {
    if (e.target === dialog) closeSheet();
  });
  function sheet(title, items, description, extra) {
    const focus = document.activeElement,
      candidate = focus && focus !== document.body ? focus : lastTrigger,
      savedFocus =
        dialog.open || (candidate && dialog.contains(candidate))
          ? lastFocus
          : candidate;
    document.activeElement?.blur();
    if (dialog.open) dialog.close();
    lastFocus = savedFocus;
    const heading = el("h2", title);
    heading.id = "sheet-title";
    dialog.setAttribute("aria-labelledby", "sheet-title");
    dialog.removeAttribute("aria-describedby");
    sheetBody.replaceChildren(el("div", undefined, "sheet-handle"), heading);
    if (description) {
      const copy = el("p", description, "muted");
      copy.id = "sheet-description";
      dialog.setAttribute("aria-describedby", "sheet-description");
      sheetBody.append(copy);
    }
    for (const item of items) {
      const action = button(
        item.label,
        async () => {
          closeSheet();
          await item.action();
        },
        `sheet-action ${item.danger ? "danger" : item.primary ? "primary" : ""}`,
      );
      if (Object.hasOwn(item, "agent"))
        action.prepend(M.agentIcon(item.agent, { el, icon }));
      sheetBody.append(action);
    }
    extra?.(sheetBody);
    sheetBody.append(button(t("Cancel"), closeSheet, "sheet-cancel"));
    document.body.classList.add("sheet-open");
    dialog.showModal();
    const input = sheetBody.querySelector(
      "input:not([type=file]):not([data-autofocus=false]),textarea:not([data-autofocus=false])",
    );
    if (input) input.focus();
  }
  function longPress(node, action, signal = abort.signal) {
    let timer,
      held = false,
      start;
    const clear = () => clearTimeout(timer),
      cleanup = () => {
        clear();
        signal?.removeEventListener("abort", clear);
      };
    node.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return;
      clear();
      held = false;
      start = { x: e.clientX, y: e.clientY };
      timer = setTimeout(() => {
        held = true;
        action();
      }, 400);
    });
    for (const kind of ["pointerup", "pointercancel", "pointerleave"])
      node.addEventListener(kind, clear);
    node.addEventListener("pointermove", (e) => {
      if (
        !start ||
        !Number.isFinite(start.x) ||
        !Number.isFinite(start.y) ||
        !Number.isFinite(e.clientX) ||
        !Number.isFinite(e.clientY) ||
        Math.hypot(e.clientX - start.x, e.clientY - start.y) > 10
      )
        clear();
    });
    node.addEventListener(
      "click",
      (e) => {
        if (held) {
          e.preventDefault();
          e.stopImmediatePropagation();
          held = false;
        }
      },
      true,
    );
    signal?.addEventListener("abort", clear, { once: true });
    return cleanup;
  }
  function applyPreferences() {
    M.i18n?.configure(state.preferences.language);
    const appearance = state.preferences.appearance || "dark";
    document.documentElement.dataset.theme = appearance;
    const light =
      appearance === "light" ||
      (appearance === "system" &&
        globalThis.matchMedia?.("(prefers-color-scheme: light)").matches);
    document
      .querySelector('meta[name="theme-color"]')
      ?.setAttribute("content", light ? "#f6f7f9" : "#111111");
    document.documentElement.style.setProperty(
      "--ui-scale",
      String(
        Math.max(1, Math.min(1.5, Number(state.preferences.uiTextScale) || 1)),
      ),
    );
  }
  function savePreferences(patch) {
    const languageChanged =
      Object.hasOwn(patch, "language") &&
      patch.language !== state.preferences.language;
    Object.assign(state.preferences, patch);
    applyPreferences();
    try {
      const saved = JSON.parse(
        localStorage.getItem("krill-mobile-ui-v1") || "{}",
      );
      localStorage.setItem(
        "krill-mobile-ui-v1",
        JSON.stringify({ ...saved, ...state.preferences }),
      );
    } catch {
      error(Error("Could not save local settings"));
    }
    if (languageChanged) render();
  }

  const pairingLink = (hash) => {
    const fragment = new URLSearchParams(hash.slice(1));
    return ["pair", "key", "t", "r"].some((key) => fragment.has(key));
  };

  let jsqr, scanner;
  const loadQr = () =>
    (jsqr ||= new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = "qr.js";
      s.onload = () => resolve(globalThis.jsQR);
      s.onerror = () => {
        jsqr = null;
        s.remove();
        reject(
          Error(
            "Could not load the QR scanner. Check the connection and try again.",
          ),
        );
      };
      document.head.append(s);
    }));
  async function readQr(source, width, height, max, detector) {
    if (detector) {
      const [code] = await detector.detect(source);
      return code?.rawValue || null;
    }
    const decode = await loadQr(),
      scale = Math.min(1, max / Math.max(width, height)),
      canvas = (readQr.canvas ||= document.createElement("canvas")),
      w = (canvas.width = Math.max(1, Math.round(width * scale))),
      h = (canvas.height = Math.max(1, Math.round(height * scale))),
      g = canvas.getContext("2d", { willReadFrequently: true });
    g.drawImage(source, 0, 0, w, h);
    return decode(g.getImageData(0, 0, w, h).data, w, h)?.data || null;
  }
  async function imageSize(file) {
    if (!file.slice) return null;
    const bytes = new Uint8Array(await file.slice(0, 512 * 1024).arrayBuffer()),
      v = new DataView(bytes.buffer);
    if (bytes.length >= 24 && v.getUint32(0) === 0x89504e47)
      return [v.getUint32(16), v.getUint32(20)];
    if (
      bytes.length >= 10 &&
      String.fromCharCode(...bytes.slice(0, 3)) === "GIF"
    )
      return [v.getUint16(6, true), v.getUint16(8, true)];
    if (
      bytes.length >= 30 &&
      String.fromCharCode(...bytes.slice(8, 16)) === "WEBPVP8X"
    )
      return [
        1 + bytes[24] + (bytes[25] << 8) + (bytes[26] << 16),
        1 + bytes[27] + (bytes[28] << 8) + (bytes[29] << 16),
      ];
    if (bytes[0] === 255 && bytes[1] === 216) {
      let at = 2;
      while (at + 8 < bytes.length) {
        if (bytes[at++] !== 255) break;
        let mark = bytes[at++];
        while (mark === 255) mark = bytes[at++];
        if (mark === 0xda || mark === 0xd9) break;
        const length = v.getUint16(at);
        if (length < 2 || at + length > bytes.length) break;
        if (
          [
            0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd,
            0xce, 0xcf,
          ].includes(mark)
        )
          return [v.getUint16(at + 5), v.getUint16(at + 3)];
        at += length;
      }
    }
    return null;
  }
  async function decodeImage(file, max) {
    if (!file || file.size > 20 * 1024 * 1024)
      throw Error("Photo must be smaller than 20 MB");
    const dimensions = await imageSize(file),
      check = (w, h) => {
        if (!Number.isFinite(w * h) || w < 1 || h < 1 || w * h > 40000000)
          throw Error("Photo pixel dimensions are too large");
      };
    if (dimensions) check(...dimensions);
    if (globalThis.createImageBitmap) {
      const resize = dimensions
        ? Math.min(1, max / Math.max(...dimensions))
        : null;
      let bitmap;
      try {
        bitmap = await createImageBitmap(
          file,
          resize
            ? {
                resizeWidth: Math.max(1, Math.round(dimensions[0] * resize)),
                resizeHeight: Math.max(1, Math.round(dimensions[1] * resize)),
                resizeQuality: "high",
              }
            : {},
        );
      } catch {}
      if (bitmap) {
        try {
          check(bitmap.width, bitmap.height);
        } catch (error) {
          bitmap.close();
          throw error;
        }
        return {
          source: bitmap,
          width: bitmap.width,
          height: bitmap.height,
          close: () => bitmap.close(),
        };
      }
    }
    const url = URL.createObjectURL(file),
      image = new Image();
    try {
      image.src = url;
      try {
        await image.decode();
      } catch {
        throw Error("Could not decode image file");
      }
      const width = image.naturalWidth || image.width,
        height = image.naturalHeight || image.height;
      check(width, height);
      return {
        source: image,
        width,
        height,
        close: () => {
          image.src = "";
          URL.revokeObjectURL(url);
        },
      };
    } catch (error) {
      URL.revokeObjectURL(url);
      throw error;
    }
  }
  async function photoQr(file, detector) {
    const image = await decodeImage(file, 2048);
    try {
      return (
        (detector &&
          (await readQr(
            image.source,
            image.width,
            image.height,
            0,
            detector,
          ).catch(() => null))) ||
        (await readQr(image.source, image.width, image.height, 1024)) ||
        (await readQr(image.source, image.width, image.height, 2048))
      );
    } finally {
      image.close();
    }
  }
  function scanQr() {
    closeSheet();
    scanner?.();
    const view = el("dialog", undefined, "scanner"),
      previousFocus = document.activeElement,
      video = el("video"),
      frame = el("div", undefined, "scanner-frame"),
      hint = el(
        "p",
        t("Point your camera at the QR code in desktop Settings → Mobile."),
        "scanner-hint",
      ),
      file = el("input"),
      bar = el("div", undefined, "scanner-actions");
    let stream,
      timer,
      done = false,
      detector = null;
    try {
      detector = globalThis.BarcodeDetector
        ? new BarcodeDetector({ formats: ["qr_code"] })
        : null;
    } catch {}
    view.setAttribute("role", "dialog");
    view.setAttribute("aria-modal", "true");
    view.setAttribute("aria-label", t("Scan QR code"));
    video.muted = true;
    video.playsInline = true;
    video.setAttribute("playsinline", "");
    video.setAttribute("aria-hidden", "true");
    file.type = "file";
    file.accept = "image/*";
    file.setAttribute("capture", "environment");
    file.hidden = true;
    const close = (scanner = () => {
        if (done) return;
        done = true;
        if (scanner === close) scanner = null;
        clearTimeout(timer);
        for (const track of stream?.getTracks() || []) track.stop();
        video.srcObject = null;
        if (view.open) view.close();
        view.remove();
        if (previousFocus?.isConnected)
          previousFocus.focus({ preventScroll: true });
      }),
      photoOnly = (message) => {
        view.classList.add("photo-only");
        video.hidden = frame.hidden = true;
        hint.textContent = t(message);
      };
    view.addEventListener("cancel", (event) => {
      event.preventDefault();
      close();
    });
    view.addEventListener("close", close);
    hint.setAttribute("role", "status");

    const found = (text) => {
      if (done) return;
      let next;
      try {
        next = endpoint.adopt(text.trim());
      } catch (e) {
        hint.textContent = t(e.message);
        return;
      }
      navigator.vibrate?.(40);
      close();
      act(() => pairWith(text.trim(), next));
    };
    file.addEventListener("change", () =>
      act(async () => {
        const f = file.files?.[0];
        file.value = "";
        if (!f) return;
        hint.textContent = t("Reading photo…");
        try {
          const text = await photoQr(f, detector);
          if (done) return;
          if (text) found(text);
          else
            hint.textContent = t(
              "No QR code found. Take the photo closer, with the whole code in view.",
            );
        } catch (e) {
          if (!done) hint.textContent = t(e?.message || String(e));
        }
      }),
    );
    bar.append(
      button(t("Take photo"), () => file.click(), "secondary"),
      button(
        t("Paste link instead"),
        () => {
          close();
          pasteLink();
        },
        "scanner-link",
      ),
    );
    view.append(
      video,
      frame,
      button(t("Close scanner"), close, "icon-button scanner-close", "close"),
      hint,
      bar,
      file,
    );
    document.getElementById("mobile-app").append(view);
    view.showModal();
    view.querySelector(".scanner-close")?.focus({ preventScroll: true });
    if (!globalThis.isSecureContext || !navigator.mediaDevices?.getUserMedia) {
      photoOnly("Take a photo of the QR code in desktop Settings → Mobile.");
      file.click();
      return;
    }
    navigator.mediaDevices
      .getUserMedia({ video: { facingMode: "environment" }, audio: false })
      .then(async (s) => {
        if (done) {
          for (const track of s.getTracks()) track.stop();
          return;
        }
        stream = s;
        video.srcObject = s;
        await video.play();
        const tick = async () => {
          if (done) return;
          try {
            const text = video.videoWidth
              ? await readQr(
                  video,
                  video.videoWidth,
                  video.videoHeight,
                  640,
                  detector,
                )
              : null;
            if (text) found(text);
          } catch (e) {
            if (!detector) {
              photoOnly(e.message);
              return;
            }
            detector = null;
          }
          if (!done) timer = setTimeout(tick, 150);
        };
        tick();
      })
      .catch(() => {
        if (!done)
          photoOnly(
            "Camera is unavailable. Take a photo of the QR code instead.",
          );
      });
  }
  function pasteLink() {
    sheet(
      t("Paste pairing link"),
      [],
      t(
        "Copy the pairing link in desktop Settings → Mobile and paste it here.",
      ),
      (body) => {
        const input = el("input");
        input.type = "url";
        input.placeholder = t("Pairing link");
        input.setAttribute("aria-label", t("Pairing link"));
        const submit = () => {
          const next = endpoint.adopt(input.value.trim());
          closeSheet();
          pairWith(input.value.trim(), next);
        };
        input.addEventListener("keydown", (e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            act(submit);
          }
        });
        body.append(input, button(t("Continue"), submit, "primary"));
      },
    );
  }

  function pairWith(text, next) {
    if (!next) {
      location.assign(text);
      return;
    }
    next.use();
    pairing = next;
    startPairing();
  }
  async function photo(session, file, options = {}) {
    if (!file || !String(file.type || "").startsWith("image/"))
      throw Error("Choose an image file");
    if (file.size > 20 * 1024 * 1024)
      throw Error("Photo must be smaller than 20 MB");
    const owner = options.owner || transport,
      generation = options.generation ?? hostGeneration,
      release = M.update?.hold?.() || (() => {});
    let image;
    try {
      image = await decodeImage(file, 1600);
      const canvas = document.createElement("canvas"),
        scale = Math.min(1, 1600 / Math.max(image.width, image.height));
      canvas.width = Math.max(1, Math.round(image.width * scale));
      canvas.height = Math.max(1, Math.round(image.height * scale));
      canvas
        .getContext("2d")
        .drawImage(image.source, 0, 0, canvas.width, canvas.height);
      let blob;
      for (const quality of [0.85, 0.65, 0.45]) {
        blob = await new Promise((r) =>
          canvas.toBlob(r, "image/jpeg", quality),
        );
        if (blob?.size <= 512 * 1024) break;
      }
      if (!blob || blob.size > 512 * 1024)
        throw Error("Photo is too large after resizing");
      let binary = "";
      for (const b of new Uint8Array(await blob.arrayBuffer()))
        binary += String.fromCharCode(b);
      const prepared = { mime: "image/jpeg", data: btoa(binary) };
      if (owner !== transport || generation !== hostGeneration)
        throw Error("Photo target changed");
      if (options.prepare) return prepared;
      await owner.rpc({ action: "photo", session, ...prepared });
      toast("Photo attached to selected session", 3000);
      return prepared;
    } finally {
      image?.close();
      release();
    }
  }

  const ios =
      /iPhone|iPad|iPod/.test(navigator.userAgent) ||
      (/Macintosh/.test(navigator.userAgent) && navigator.maxTouchPoints > 1),
    standalone = () =>
      !!globalThis.matchMedia?.("(display-mode: standalone)").matches ||
      navigator.standalone === true;
  const android = /Android/i.test(navigator.userAgent),
    installed = standalone;

  if (ios) document.querySelector("link[rel=manifest]")?.remove();
  async function installIos() {
    if (!credentials) {
      sheet(
        t("Add Krill to your Home Screen"),
        [],
        t(
          "Tap Share, then Add to Home Screen. Open it and scan the desktop QR code if asked.",
        ),
      );
      return;
    }
    const { fragment } = await transport.rpc({ action: "install_handoff" });
    if (
      typeof fragment !== "string" ||
      !/^pair=[0-9a-f]{64}&key=[\w-]{43}(?:&t=(?=[a-zA-Z0-9.-]{1,253}(?:&|$))[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+)?(?:&r=[0-9a-f]{32})?$/.test(
        fragment,
      )
    )
      throw Error("Could not prepare the Home Screen app");
    history.replaceState(
      {},
      "",
      location.pathname + location.search + "#" + fragment + "&install=1",
    );
    sheet(
      t("Add Krill to your Home Screen"),
      [],
      t(
        "The Home Screen app connects as its own device. You can remove it from desktop Settings → Mobile.",
      ),
      (body) => {
        const steps = el("ol", undefined, "install-steps");
        for (const text of [
          "Tap Share in the Safari toolbar.",
          "Choose Add to Home Screen, then Add.",
          "Within 5 minutes, open Krill from your Home Screen.",
        ])
          steps.append(el("li", t(text)));
        body.append(steps);
      },
    );
  }
  async function installAndroid() {
    if (credentials) {
      const { fragment } = await transport.rpc({ action: "install_handoff" });
      if (
        typeof fragment !== "string" ||
        !/^pair=[0-9a-f]{64}&key=[\w-]{43}(?:&t=(?=[a-zA-Z0-9.-]{1,253}(?:&|$))[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+)?(?:&r=[0-9a-f]{32})?$/.test(
          fragment,
        )
      )
        throw Error("Could not prepare the Home Screen app");
      history.replaceState(
        {},
        "",
        location.pathname + location.search + "#" + fragment + "&install=1",
      );
    }
    sheet(
      t("Add Krill to your Home Screen"),
      install.prompt
        ? [{ label: t("Install"), primary: true, action: () => install.show() }]
        : [],
      t("Open your browser menu and choose Install app or Add to Home Screen."),
      (body) => {
        const steps = el("ol", undefined, "install-steps");
        for (const text of [
          "Open your browser menu (⋮).",
          "Choose Install app or Add to Home screen.",
          "Within 5 minutes, open Krill from your Home Screen.",
        ])
          steps.append(el("li", t(text)));
        body.append(steps);
      },
    );
  }
  const install = (M.install = {
    prompt: null,
    ios,
    async show() {
      if (installed()) return false;
      if (this.prompt) {
        const p = this.prompt;
        this.prompt = null;
        try {
          await p.prompt();
          await p.userChoice;
        } catch {}
        update();
        return true;
      }
      if (ios) return installIos();
      if (android) return installAndroid();
      return offerInstall(true);
    },
    get offer() {
      if (installed()) return null;
      if (this.prompt) return "prompt";
      if (ios && credentials) return "ios";
      if (android && credentials) return "android";
      return null;
    },
    async accept() {
      return this.show();
    },
    dismiss() {
      savePreferences({ installDismissed: true });
      render();
    },
  });
  globalThis.addEventListener("beforeinstallprompt", (event) => {
    event.preventDefault();
    install.prompt = event;
    update();
    if (credentials && !landing && !state.preferences.installOffered)
      offerInstall();
  });
  globalThis.addEventListener("appinstalled", () => {
    install.prompt = null;
    update();
  });
  function parseRoute() {
    const parts = (location.hash.slice(1) || "/").split("/").slice(1);
    if (parts[0] === "host") {
      if (parts[1] !== "local" && "/host/" + parts[1] !== hostRoute())
        return { screen: "home" };
      if (parts[2] === "group") {
        let key;
        try {
          key = decodeURIComponent(parts[3]);
        } catch {
          throw Error("Invalid workspace link");
        }
        if (parts[4] === "s" && parts[5] === "new")
          return { screen: "session", groupKey: key, sessionId: "new" };
        const id = parts[4] === "s" ? Number(parts[5]) : undefined;
        if (id !== undefined && (!Number.isSafeInteger(id) || id <= 0))
          throw Error("Invalid session link");
        return { screen: "session", groupKey: key, sessionId: id };
      }
      return { screen: "workspaces" };
    }
    if (parts[0] === "git") {
      const id = Number(parts[1]);
      if (!Number.isSafeInteger(id) || id <= 0)
        throw Error("Invalid session link");
      return { screen: "git", sessionId: id };
    }
    return {
      screen: [
        "accounts",
        "orchestration",
        "settings",
        "diagnostics",
        "pair-confirm",
      ].includes(parts[0])
        ? parts[0]
        : "home",
      subpage: parts[1],
    };
  }
  let pendingRecent = null,
    tabletShell,
    tabletSidebar,
    tabletBody,
    tabletList,
    tabletAbort,
    tabletContext,
    tabletCtxRef,
    tabletHost,
    tabletCollapsed;
  const tabletMedia = globalThis.matchMedia?.("(min-width:1000px)");
  function syncTablet() {
    if (!tabletShell) return;
    tabletShell.classList.toggle(
      "sidebar-collapsed",
      !!state.preferences.tabletSidebarCollapsed,
    );
    const visible =
      !!tabletMedia?.matches &&
      !state.preferences.tabletSidebarCollapsed &&
      !document.hidden;
    if (!visible) {
      tabletList?.cleanup?.();
      tabletAbort?.abort();
      tabletList = null;
      tabletSidebar.replaceChildren();
      return;
    }
    if (!tabletList && tabletContext) {
      tabletAbort = new AbortController();
      const signal = tabletAbort.signal,
        ctx = tabletContext;
      tabletHost = ctx.hosts?.find((h) => h.active)?.id;
      tabletCollapsed = !!state.preferences.tabletSidebarCollapsed;
      tabletList = M.screens.workspaces(tabletSidebar, {
        ...ctx,
        state: Object.assign(Object.create(state), {
          ui: { search: "", filter: "all" },
        }),
        signal,
        sidebar: true,
        refresh: () => tabletCtxRef.ctx.refresh(),
        createSession: (...args) => tabletCtxRef.ctx.createSession(...args),
        rpc: (request) => {
          if (signal.aborted || !tabletCtxRef)
            throw Error("Screen target changed");
          return tabletCtxRef.rpc(request, signal);
        },
      });
    }
  }
  tabletMedia?.addEventListener?.("change", syncTablet);
  document.addEventListener("visibilitychange", syncTablet);
  function rememberSession(session, group) {
    if (
      state.cached ||
      state.connection.phase !== "ready" ||
      (state.lastSession?.id === session.id &&
        state.lastSession?.groupKey === group?.key &&
        state.lastSession?.device === credentials?.device_id)
    )
      return;
    state.lastSession =
      M.recentSession.write(credentials?.device_id, session, group) ||
      state.lastSession;
  }
  function resumeLastSession() {
    if (transport.blocked) {
      scanQr();
      return;
    }
    pendingRecent = state.lastSession;
    transport.resume();
  }
  const screenLoads = new Map(),
    routeAssets = {
      accounts: "screens/details.js",
      git: "screens/details.js",
      orchestration: "screens/details.js",
      settings: "screens/settings.js",
      diagnostics: "screens/settings.js",
    };
  function loadScreen(name) {
    const path = routeAssets[name];
    if (!path || M.screens[name]) return Promise.resolve();
    if (screenLoads.has(path)) return screenLoads.get(path);
    const pending = new Promise((resolve, reject) => {
      const script = el("script");
      script.src = path;
      script.onload = () => resolve();
      script.onerror = () => {
        screenLoads.delete(path);
        script.remove();
        reject(
          Error(
            "Could not load this screen. Check the connection and try again.",
          ),
        );
      };
      document.head.append(script);
    });
    screenLoads.set(path, pending);
    return pending;
  }
  function render() {
    let nextRoute;
    try {
      nextRoute = parseRoute();
    } catch {
      nextRoute = { screen: "home" };
    }
    const keepTablet =
      nextRoute.screen === "session" &&
      activeRouteScreen === "session" &&
      tabletShell;
    const previousRoute = routeKey,
      routeChanged = previousRoute !== location.hash,
      focus = document.activeElement,
      focusKey = focus?.dataset?.focusKey,
      oldScroll = Array.from(
        root.querySelectorAll(
          ".home-list,.workspace-list,.detail-list,.account-list,.settings-list,.connection-log",
        ),
      ).map((n) => [n.className, n.scrollTop]);
    screen?.cleanup?.();
    abort?.abort();
    abort = new AbortController();
    if (keepTablet) tabletBody.replaceChildren();
    else {
      tabletList?.cleanup?.();
      tabletAbort?.abort();
      tabletList = null;
      tabletContext = null;
      tabletShell = null;
      root.replaceChildren();
    }
    let route;
    try {
      route = parseRoute();
    } catch (e) {
      error(e);
      route = { screen: "home" };
    }
    routeKey = location.hash;
    activeRouteScreen = route.screen;
    document.body.dataset.screen = route.screen;
    banner.hidden =
      (route.screen === "home" && state.connection.phase !== "auth_required") ||
      ["ready", "idle"].includes(state.connection.phase);
    const screenTransport = transport,
      screenGeneration = hostGeneration,
      screenSignal = abort.signal,
      assertOwner = () => {
        if (
          screenSignal.aborted ||
          screenGeneration !== hostGeneration ||
          screenTransport !== transport
        )
          throw Error("Screen target changed");
        if (state.cached || !screenTransport.ready)
          throw Error("Reconnect to desktop first");
      };
    const ctx = {
      el,
      button,
      icon,
      go,
      back,
      backTo,
      t,
      install,
      state,
      route,
      signal: abort.signal,
      header,
      dot,
      rollup,
      groupRoute,
      linkRow,
      sheet,
      closeSheet,
      longPress,
      savePreferences,
      rememberSession,
      resumeLastSession,
      scanQr,
      pasteLink,
      newWorkspace,
      sessionKey,
      hosts: endpoint.profiles(),
      getHosts: () => endpoint.profiles(),
      selectHost,
      forgetHost,
      renameHost,
      hostRoute,
      getConnections,
      openRecent,
      reconnectHost,
      photo: (session, file, options = {}) => {
        assertOwner();
        return photo(session, file, {
          ...options,
          owner: screenTransport,
          generation: screenGeneration,
        });
      },
      toast,
      error,
      act,
      transport: screenTransport,
      rpc: (request) => {
        assertOwner();
        return screenTransport.rpc(request);
      },
      rpcLatest: (key, request) => {
        assertOwner();
        return screenTransport.rpcLatest(key, request);
      },
      refresh: () => {
        assertOwner();
        return screenTransport.refresh().then((data) => {
          if (
            data &&
            transport === screenTransport &&
            screenGeneration === hostGeneration
          )
            snapshot(data, false);
          return data;
        });
      },
      rerender: render,
      createSession: (group, agent, request) => {
        assertOwner();
        return createSession(group, agent, request);
      },
      creating: () => creating,
    };
    if (routeAssets[route.screen] && !M.screens[route.screen]) {
      root.append(header("Krill", "/"));
      const status = el("p", t("Loading…"), "empty");
      root.append(status);
      screen = {};
      const key = routeKey,
        generation = hostGeneration;
      loadScreen(route.screen).then(
        () => {
          if (routeKey === key && generation === hostGeneration) render();
        },
        (e) => {
          if (routeKey !== key || generation !== hostGeneration) return;
          status.textContent = t(e.message);
          root.append(button(t("Retry"), render, "secondary"));
        },
      );
      return;
    }
    if (route.screen === "pair-confirm") {
      const section = el("section", undefined, "pair-screen screen");
      section.append(
        header("Pair Desktop", "/"),
        el("h1", t("Connect your desktop")),
        el(
          "p",
          t(
            pairing
              ? "Add this desktop to your saved desktops. You can switch between them from Home."
              : "Pair with Krill on your computer to check on your agents, jump into any terminal, and drive work from your phone.",
          ),
          "pair-copy",
        ),
      );
      if (pairing)
        section.append(
          button(t("Pair"), startPairing, "primary"),
          button(
            t("Cancel"),
            () => {
              pairing = null;
              credentials = endpoint.restoreSaved?.() || endpoint.saved || null;
              if (!pool?.owns(transport)) transport.close();
              pool?.sync();
              const entry = pool?.get(
                endpoint.profiles().find((h) => h.active)?.id,
              );
              transport = entry?.transport || createTransport();
              if (entry) activateEntry(entry);
              go("/", true);
            },
            "secondary",
          ),
        );
      else section.append(button(t("Scan QR code"), scanQr, "primary"));
      root.append(section);
      screen = {};
      return;
    }
    if (
      (!state.snapshot || (state.cached && route.screen !== "workspaces")) &&
      route.screen !== "home" &&
      !["settings", "diagnostics"].includes(route.screen) &&
      (route.screen !== "accounts" || !endpoint.profiles().length)
    ) {
      root.append(
        header(
          "Krill",
          "/",
          route.screen === "session" ? () => go("/host/local") : undefined,
        ),
        el("p", t(state.connection.message), "empty"),
      );
      if (!endpoint.profiles().length)
        root.append(
          el(
            "p",
            t("Open Krill desktop → Settings → Mobile, then scan the QR code."),
            "empty",
          ),
          button(t("Scan QR code"), scanQr, "primary"),
          button(t("Paste pairing link"), pasteLink, "text-button"),
        );
      screen = {};
      return;
    }
    if (route.screen === "session") {
      if (!tabletShell) {
        tabletShell = el("div", undefined, "tablet-shell");
        tabletSidebar = el("aside", undefined, "tablet-sidebar");
        tabletSidebar.setAttribute("aria-label", t("Sessions"));
        tabletBody = el("main", undefined, "tablet-body");
        tabletShell.append(tabletSidebar, tabletBody);
        root.append(tabletShell);
      }
      tabletCtxRef = {
        ctx,
        rpc: (request, signal) => {
          if (
            signal.aborted ||
            screenGeneration !== hostGeneration ||
            screenTransport !== transport
          )
            throw Error("Screen target changed");
          if (state.cached || !screenTransport.ready)
            throw Error("Reconnect to desktop first");
          return screenTransport.rpc(request);
        },
      };
      tabletContext = ctx;
      if (
        tabletList &&
        (!keepTablet ||
          tabletHost !== ctx.hosts.find((h) => h.active)?.id ||
          tabletCollapsed !== !!state.preferences.tabletSidebarCollapsed)
      ) {
        tabletList.cleanup?.();
        tabletAbort?.abort();
        tabletList = null;
        tabletSidebar.replaceChildren();
      }
      syncTablet();
      const sessionHeader = (...args) => {
        const h = header(...args),
          backButton = h.querySelector("button");
        backButton.classList.add("session-back");
        const syncToggle = () => {
          const collapsed = !!state.preferences.tabletSidebarCollapsed,
            label = t(collapsed ? "Show session list" : "Hide session list");
          tabletShell.classList.toggle("sidebar-collapsed", collapsed);
          toggle.setAttribute("aria-expanded", String(!collapsed));
          toggle.setAttribute("aria-label", label);
          toggle.title = label;
        };
        const toggle = button(
          t("Hide session list"),
          () => {
            savePreferences({
              tabletSidebarCollapsed: !state.preferences.tabletSidebarCollapsed,
            });
            syncToggle();
            syncTablet();
          },
          "icon-button tablet-sidebar-toggle",
          "panelLeft",
        );
        syncToggle();
        h.prepend(toggle);
        return h;
      };
      screen =
        M.screens.session(tabletBody, { ...ctx, header: sessionHeader }) || {};
      tabletList?.update?.();
    } else
      screen = (M.screens[route.screen] || M.screens.home)(root, ctx) || {};
    const heading = (
      route.screen === "session" ? tabletBody : root
    )?.querySelector("h1");
    document.title = heading?.textContent
      ? `${heading.textContent} · Krill`
      : "Krill";
    if (routeChanged && heading) {
      heading.tabIndex = -1;
      heading.focus({ preventScroll: true });
    } else {
      for (const [cls, top] of oldScroll) {
        const node = Array.from(
          root.querySelectorAll(
            ".home-list,.workspace-list,.detail-list,.account-list,.settings-list,.connection-log",
          ),
        ).find((n) => n.className === cls);
        if (node) node.scrollTop = top;
      }
      if (focusKey)
        Array.from(root.querySelectorAll("[data-focus-key]"))
          .find((n) => n.dataset.focusKey === focusKey)
          ?.focus({ preventScroll: true });
    }
  }
  // IME(한글) 조합 중에는 스냅샷으로 화면을 갱신하지 않는다. 조합이 끝나거나 포커스를 잃으면 한 번 따라잡는다.
  let imeComposing = false,
    imeMissed = false;
  const imeSettle = () => {
    if (!imeComposing) return;
    imeComposing = false;
    if (imeMissed) {
      imeMissed = false;
      update();
    }
  };
  document.addEventListener(
    "compositionstart",
    () => {
      imeComposing = true;
    },
    true,
  );
  document.addEventListener("compositionend", imeSettle, true);
  document.addEventListener("focusout", imeSettle, true);
  function update() {
    if (routeKey !== location.hash || document.hidden) return;
    if (imeComposing) {
      imeMissed = true;
      return;
    }
    screen?.update?.();
    if (tabletMedia?.matches && !state.preferences.tabletSidebarCollapsed)
      tabletList?.update?.();
  }
  function group(data) {
    state.snapshot = data;
    state.groups = new Map(
      (data.workspaces || []).map((w) => [
        w.key,
        {
          key: w.key,
          label: w.label,
          path: w.path,
          repoKey: w.repo_key,
          pinned: w.pinned,
          branch: w.branch,
          depth: w.depth,
          primary: w.primary,
          icon: w.icon,
          visibility: w.visibility,
          orders: w.orders,
          parent: w.parent,
          status: w.status,
          sessions: [],
        },
      ]),
    );
    state.sessions = new Map();
    for (const s of data.sessions || []) {
      if (s.exited || s.state === "Exited") {
        state.expected?.delete(s.id);
        continue;
      }
      const key =
        s.worktree_key || (s.cwd ? `cwd:${s.cwd}` : `unknown:${s.id}`);
      let group = state.groups.get(key);
      if (!group) {
        group = {
          key,
          label:
            M.sessionPathLabel(s, data.host?.platform) ||
            M.i18n?.t?.("Workspace") ||
            "Workspace",
          path: s.group_path || s.cwd,
          repoKey: s.repo_key,
          sessions: [],
        };
        state.groups.set(key, group);
      }
      group.sessions.push(s);
      s.groupKey = key;
      state.sessions.set(s.id, s);
    }
    for (const [id, e] of state.expected || []) {
      if (
        state.sessions.has(id) ||
        e.session.exited ||
        e.session.state === "Exited" ||
        Date.now() - e.at > 30000
      ) {
        state.expected.delete(id);
        continue;
      }
      const s = e.session;
      let group = state.groups.get(s.groupKey);
      if (!group) {
        group = {
          key: s.groupKey,
          label: s.group_label || M.i18n?.t?.("Workspace") || "Workspace",
          path: s.group_path,
          repoKey: s.repo_key,
          sessions: [],
        };
        state.groups.set(group.key, group);
      }
      group.sessions.push(s);
      state.sessions.set(id, s);
    }
    M.chat?.pruneCache?.(state);
    M.terminal?.pruneSessions?.(state.sessions, sessionScope() + "\n");
  }

  let creating = null;
  function createSession(workspace, agent, request) {
    const owner = transport,
      generation = hostGeneration,
      job = { group: workspace, agent: agent || "" },
      waiting = () => {
        try {
          const r = parseRoute();
          return (
            creating === job &&
            r.screen === "session" &&
            r.sessionId === "new" &&
            r.groupKey === workspace.key
          );
        } catch {
          return false;
        }
      };
    creating = job;
    go(`/host/local/group/${encodeURIComponent(workspace.key)}/s/new`);
    owner.prewarmTerminal?.();
    return owner
      .rpc(request)
      .then((result) => {
        const here = waiting();
        if (creating === job) creating = null;
        if (generation !== hostGeneration) return;
        const id = result?.session;
        if (!Number.isSafeInteger(id) || id <= 0)
          throw Error("Unexpected daemon response");
        if (!state.sessions.has(id)) {
          const s = {
            id,
            agent: job.agent,
            title: "",
            state: "Unknown",
            exited: false,
            lines: [],
            cwd: workspace.path || "",
            worktree_key: workspace.key,
            repo_key: workspace.repoKey,
            group_label: workspace.label,
            group_path: workspace.path,
            branch:
              workspace.sessions.find(
                (s) => s.branch !== null && s.branch !== undefined,
              )?.branch ??
              workspace.branch ??
              null,
            state_since_unix_ns: `${Date.now()}000000`,
            groupKey: workspace.key,
          };
          (state.expected ||= new Map()).set(id, {
            session: s,
            at: Date.now(),
          });
          if (state.snapshot) group(state.snapshot);
        }
        if (here)
          go(
            groupRoute(
              state.groups.get(state.sessions.get(id)?.groupKey) || workspace,
              id,
            ),
            true,
          );
        else update();
        owner.refresh().catch(() => {});
      })
      .catch((e) => {
        const here = waiting();
        if (creating === job) creating = null;
        if (generation !== hostGeneration) return;
        error(e);
        if (here) back(groupRoute(state.groups.get(workspace.key)));
        else update();
      });
  }
  function snapshot(data, draw = true) {
    try {
      endpoint.describeHost(data.host);
    } catch {
      error(Error("Could not save desktop details"));
    }
    group(data);
    state.cached = false;
    if (pendingRecent) {
      const target = pendingRecent;
      pendingRecent = null;
      const s = M.recentSession.resolve({ ...state, lastSession: target });
      if (s) {
        go(groupRoute(state.groups.get(s.groupKey), s.id), true);
        return;
      }
      error(Error("Session no longer available."));
    }
    if (deepLink !== null) {
      const id = Number(deepLink);
      deepLink = null;
      parameters.delete("session");
      history.replaceState(
        {},
        "",
        location.pathname +
          (parameters.size ? "?" + parameters : "") +
          location.hash,
      );
      const session = state.sessions.get(id);
      if (Number.isSafeInteger(id) && session)
        go(groupRoute(state.groups.get(session.groupKey), id), true);
      else {
        error(Error("Session not found"));
        go("/host/local", true);
      }
      return;
    }
    if (
      !root.querySelector(".screen") ||
      (root.querySelector(".empty") &&
        !root.querySelector(".workspace-list,.detail-list"))
    )
      render();
    else if (draw) update();
  }
  function showConnection(status) {
    const previous = state.connection;
    state.connection = status;
    if (
      previous.phase !== status.phase ||
      previous.message !== status.message
    ) {
      state.logs.push({
        at: Date.now(),
        host: endpoint.profiles().find((h) => h.active)?.name,
        phase: status.phase,
        message: status.message,
      });
      state.logs = state.logs.slice(-100);
      state.logRevision = (state.logRevision || 0) + 1;
    }
    banner.replaceChildren(el("span", t(status.message)));
    if (status.retryAt > Date.now())
      banner.append(
        el(
          "small",
          t(
            "Next retry in {0}s",
            Math.ceil((status.retryAt - Date.now()) / 1000),
          ),
          "muted",
        ),
      );
    if (status.phase !== "ready" && status.phase !== "idle") {
      const actions = el("span", undefined, "connection-actions");
      actions.append(
        button(t("Reconnect"), () => transport.reconnect(), "banner-action"),
        button(t("Scan QR"), scanQr, "banner-action"),
      );
      banner.append(actions);
    }
    banner.hidden =
      status.phase === "ready" ||
      status.phase === "idle" ||
      activeRouteScreen === "home";
    banner.className = `connection-banner ${status.phase}`;
    if (status.phase === "ready" && !state.cached) {
      hideNotice();
      notice.textContent = "";
      state.hasConnected = true;
      if (pendingHostAction) {
        const action = pendingHostAction;
        pendingHostAction = null;
        action();
      }
    }
    update();
  }
  function createTransport(pair) {
    const mine = M.transport.create({
      endpoint,
      credentials,
      pair,
      warmTerminal: false,
      label: /iPhone|iPad/.test(navigator.userAgent)
        ? "iPhone / iPad (Safari)"
        : "Mobile browser",
      onAuthenticated: (auth) => {
        if (transport !== mine) return;
        credentials = auth;
        state.lastSession = M.recentSession.read(auth.device_id);
        if (endpoint.storageFailed)
          error(Error("Could not save pairing. Keep this page open."));
      },
      onSnapshot: (data) => {
        if (transport === mine) snapshot(data);
      },
      onError: (e) => {
        if (transport === mine) error(e);
      },
      onStatus: (status) => {
        if (transport !== mine) return;
        showConnection(status);
        if (status.phase === "ready" && landing) {
          landing = false;
          const id = endpoint.profiles().find((h) => h.active)?.id;
          setTimeout(() => {
            if (transport !== mine || !id) return;
            pool.sync();
            selectHost(id);
            offerInstall();
          }, 0);
        }
      },
    });
    return mine;
  }
  const viewKey = (id, device) => JSON.stringify([id, device]);

  const hostViewPins = new WeakSet(),
    hostViewLimit = 8,
    hostViewByteLimit = 32 * 1024 * 1024;
  function hostViewPinned(view) {
    return (
      hostViewPins.has(view) ||
      [...(view.drafts?.values() || [])].some(Boolean) ||
      [...(view.chatCache?.values() || [])].some(
        (e) =>
          e.mounts > 0 ||
          e.sending || e.modelPending ||
          e.questionSending ||
          e.questionDraft?.changed ||
          e.questionDraft?.selected?.length ||
          e.photo ||
          e.live,
      )
    );
  }
  function hostViewWeight(view) {
    let bytes = 0;
    for (const value of view.titles?.values() || [])
      bytes += String(value).length * 2;
    for (const entry of view.chatCache?.values() || [])
      bytes +=
        (entry.retainedBytes || 0) +
        (entry.pages?.length || 0) * 16 +
        (entry.disclosures?.size || 0) * 64;
    return bytes;
  }
  function pruneHostViews(
    activeKey = activeView && viewKey(activeView.id, activeView.device),
  ) {
    let bytes = 0;
    for (const [key, view] of hostViews) {
      if (key !== activeKey && !hostViewPinned(view))
        M.chat?.pruneCache?.(view);
      bytes += hostViewWeight(view);
    }
    for (const [key, view] of hostViews) {
      if (hostViews.size <= hostViewLimit && bytes <= hostViewByteLimit) break;
      if (key !== activeKey && !hostViewPinned(view)) {
        hostViews.delete(key);
        bytes -= hostViewWeight(view);
      }
    }
  }
  function rememberHostView(id, device) {
    if (!id || !device) return;
    const view = {
        drafts: state.drafts,
        chatCache: state.chatCache,
        titles: state.titles,
        ui: { ...state.ui },
      },
      selection = globalThis.getSelection?.();
    if (
      M.terminal?.updateBusy?.(sessionScope() + "\n") ||
      (selection &&
        !selection.isCollapsed &&
        root.contains?.(selection.anchorNode)) ||
      document.querySelector(
        ".chat-opt[aria-pressed=true],.file-row[aria-pressed=true]",
      )
    )
      hostViewPins.add(view);
    const key = viewKey(id, device);
    hostViews.delete(key);
    hostViews.set(key, view);
  }
  let pendingHostAction = null;
  function clearHost(remember = true) {
    const id = activeView?.id,
      device = activeView?.device;
    activeView = null;
    if (remember) rememberHostView(id, device);
    hostGeneration++;
    tabletList?.cleanup?.();
    tabletAbort?.abort();
    tabletList = null;
    tabletContext = null;
    tabletShell = null;
    M.update?.invalidate();
    screen?.cleanup?.();
    abort?.abort();
    const previous = transport;
    previous?.setActive?.(false);
    transport = null;
    if (previous && !pool?.owns(previous)) previous.close();
    pendingRecent = null;
    deepLink = null;
    parameters.delete("session");
    history.replaceState(
      {},
      "",
      location.pathname +
        (parameters.size ? "?" + parameters : "") +
        location.hash,
    );
    Object.assign(state, {
      snapshot: null,
      cached: false,
      lastSession: null,
      groups: new Map(),
      sessions: new Map(),
      expected: new Map(),
      drafts: new Map(),
      chatCache: new Map(),
      titles: new Map(),
      ui: { search: "", filter: "all" },
    });
    document
      .querySelector('link[rel="manifest"]')
      ?.setAttribute("href", "manifest.json");
    pruneHostViews(null);
  }
  function activateEntry(entry) {
    credentials = endpoint.selectHost(entry.id);
    activeView = { id: entry.id, device: credentials.device_id };
    transport = entry.transport;
    transport.setActive?.(true);
    const key = viewKey(entry.id, credentials.device_id),
      saved = hostViews.get(key);
    if (saved) {
      Object.assign(state, saved);
      hostViews.delete(key);
      hostViews.set(key, saved);
    }
    pruneHostViews(key);
    state.lastSession = M.recentSession.read(credentials.device_id);
    state.connection = entry.connection;
    state.cached = entry.cached;
    if (entry.snapshot) group(entry.snapshot);
  }
  function receiveEntry() {
    if (entryDrawPending) return;
    entryDrawPending = true;
    (globalThis.requestAnimationFrame || queueMicrotask)(() => {
      entryDrawPending = false;
      if (document.hidden) return;
      const entry = pool
        ?.entries()
        .find((e) => e.transport === transport && e.id === activeView?.id);
      if (entry) {
        if (entry.snapshot && state.snapshot !== entry.snapshot) {
          if (entry.cached) {
            group(entry.snapshot);
            state.cached = true;
            render();
          } else snapshot(entry.snapshot, false);
        } else if (
          !entry.snapshot &&
          (state.cached || entry.connection.blocked)
        ) {
          state.snapshot = null;
          state.cached = false;
          state.groups.clear();
          state.sessions.clear();
          render();
        }
        showConnection(entry.connection);
      } else if (activeRouteScreen === "home") update();
    });
  }
  function startPairing() {
    pendingHostAction = null;
    clearHost();
    credentials = null;
    transport = createTransport(pairing);
    pairing = null;
    landing = true;
    routeStack = ["#/"];
    go("/", true);
    transport.connect();
  }
  function selectHost(id, after) {
    const selected = endpoint.profiles().find((h) => h.id === id);
    if (!selected) throw Error("Desktop is no longer saved.");
    pool.sync();
    const entry = pool.get(id);
    if (selected.active && transport === entry.transport) {
      if (transport.ready && !state.cached && after) after();
      else {
        pendingHostAction = after || null;
        go("/host/local");
      }
      return;
    }
    landing = false;
    clearHost();
    pendingHostAction = after || null;
    activateEntry(entry);
    routeStack = ["#/"];
    go("/host/local", true);
    if (entry.connection.phase === "ready") showConnection(entry.connection);
  }
  function getConnections() {
    return endpoint.profiles().map((profile) => {
      const entry = pool?.get(profile.id);
      return {
        ...profile,
        connection: entry?.connection || {
          phase: "idle",
          message: "Not connected",
        },
        snapshot: entry?.snapshot || null,
        cached: !!entry?.cached,
        recent:
          M.recentSession.list?.(entry?.endpoint.credentials.device_id) || [],
        workspaceView:
          state.preferences.workspaceViews?.[
            JSON.stringify([
              profile.id,
              entry?.endpoint.credentials?.device_id,
            ]) + "\nworkspace-view"
          ],
      };
    });
  }
  function reconnectHost(id) {
    pool?.get(id)?.transport.reconnect();
  }
  function openRecent(id, locator) {
    selectHost(id, () => {
      const session = state.sessions.get(locator.id);
      if (
        !session ||
        session.exited ||
        session.state === "Exited" ||
        session.groupKey !== locator.groupKey
      ) {
        error(Error("Session no longer available."));
        return;
      }
      go(groupRoute(state.groups.get(session.groupKey), session.id));
    });
  }
  function renameHost(id) {
    const host = endpoint.profiles().find((h) => h.id === id);
    if (!host) return;
    sheet(
      t("Rename desktop"),
      [],
      t("This name is saved on this phone."),
      (body) => {
        const form = el("form"),
          label = el("label", t("Desktop name")),
          input = el("input"),
          message = el("p", undefined, "inline-status"),
          save = button(t("Save"), () => {}, "primary");
        input.id = "desktop-name";
        input.type = "text";
        input.value = host.name;
        input.required = true;
        input.maxLength = 80;
        input.autocomplete = "off";
        label.htmlFor = input.id;
        message.setAttribute("role", "alert");
        message.hidden = true;
        save.type = "submit";
        form.append(label, input, message, save);
        form.addEventListener("submit", (event) => {
          event.preventDefault();
          try {
            endpoint.renameHost(id, input.value);
            closeSheet();
            render();
          } catch (e) {
            message.textContent = t(e.message);
            message.hidden = false;
          }
        });
        body.append(form);
      },
    );
  }
  function forgetHost(id) {
    const host = endpoint.profiles().find((h) => h.id === id);
    if (!host) return;
    sheet(
      t("Remove saved desktop?"),
      [
        {
          label: t("Remove from this phone"),
          danger: true,
          action: () => {
            const wasActive = endpoint
              .profiles()
              .find((h) => h.id === id)?.active;
            const nextId = endpoint.forgetHost(id);
            pool?.sync();
            for (const key of hostViews.keys())
              if (JSON.parse(key)[0] === id) hostViews.delete(key);
            if (wasActive) {
              pendingHostAction = null;
              clearHost(false);
              credentials = null;
              transport = createTransport();
              const entry = nextId && pool?.get(nextId);
              if (entry) activateEntry(entry);
              else
                state.connection = { phase: "idle", message: "Not connected" };
              routeStack = ["#/"];
              go("/", true);
            } else render();
          },
        },
      ],
      host.name,
    );
  }
  function newWorkspace(defaultRepoKey) {
    if (parseRoute().screen !== "home" && transport.ready) {
      workspaceComposer(defaultRepoKey);
      return;
    }
    const hosts = endpoint.profiles();
    if (hosts.length > 1) {
      sheet(
        t("Choose desktop"),
        hosts.map((h) => ({
          label: `${h.name} · ${h.endpoint}`,
          action: () =>
            selectHost(h.id, () => workspaceComposer(defaultRepoKey)),
        })),
      );
      return;
    }
    if (transport.ready) workspaceComposer(defaultRepoKey);
  }
  function workspaceComposer(defaultRepoKey) {
    const current = transport;
    M.workspaceComposer(
      {
        el,
        button,
        icon,
        go,
        t,
        state,
        sheet,
        closeSheet,
        toast,
        error,
        act,
        groupRoute,
        getHosts: () => endpoint.profiles(),
        selectHost,
        newWorkspace,
        isOpen: (node) => dialog.open && sheetBody.contains(node),
        rpc: (request) => {
          if (transport !== current || !current.ready)
            throw Error("Reconnect to desktop first");
          return current.rpc(request);
        },
        refresh: () =>
          current.refresh().then((data) => {
            if (data && transport === current) snapshot(data, false);
            return data;
          }),
        onCreated: (result, agent) => {
          if (result.session && !state.sessions.has(result.session))
            (state.expected ||= new Map()).set(result.session, {
              session: {
                id: result.session,
                agent: agent || "",
                title: "",
                state: "Unknown",
                exited: false,
                lines: [],
                cwd: result.path || "",
                worktree_key: result.workspace,
                groupKey: result.workspace,
              },
              at: Date.now(),
            });
        },
      },
      defaultRepoKey,
    );
  }

  function offerInstall(force = false) {
    if (
      installed() ||
      (!force &&
        (!install.offer ||
          state.preferences.installOffered ||
          state.preferences.installDismissed ||
          offerInstall.queued))
    )
      return false;
    const show = async () => {
      offerInstall.queued = false;
      const offer = install.offer;
      if (
        installed() ||
        (!force &&
          (!offer ||
            state.preferences.installOffered ||
            state.preferences.installDismissed ||
            dialog.open ||
            scanner))
      )
        return false;
      savePreferences({ installOffered: true });
      if (offer === "ios") {
        await installIos();
        return true;
      }
      if (offer === "android" || (android && offer === "prompt")) {
        await installAndroid();
        return true;
      }
      sheet(
        t("Install Krill"),
        offer === "prompt"
          ? [
              {
                label: t("Install"),
                primary: true,
                action: () => install.show(),
              },
            ]
          : [],
        t(
          offer === "prompt"
            ? "Open Krill full screen from your home screen."
            : "Open your browser menu and choose Install app or Add to Home Screen.",
        ),
      );
      return true;
    };
    if (force) return show();
    offerInstall.queued = true;
    setTimeout(() => show().catch(error), 1200);
    return true;
  }
  transport = createTransport();
  pool = M.transport.pool({ endpoint, onChange: receiveEntry });
  pool.sync();
  const initialEntry = pool.get(endpoint.profiles().find((h) => h.active)?.id);
  if (initialEntry && !pairing) activateEntry(initialEntry);
  M.app = {
    navigate: go,
    selectHost,
    getConnections,
    refresh: () => {
      const current = transport;
      return current.refresh().then((data) => {
        if (data && transport === current) snapshot(data, false);
        return data;
      });
    },
    get transport() {
      return transport;
    },
  };
  globalThis.addEventListener("hashchange", () => {
    if (pairingLink(location.hash)) {
      location.reload();
      return;
    }
    pendingRecent = null;
    if (dialog.open) closeSheet();
    scanner?.();
    const hash = location.hash || "#/";
    if (historyBack) {
      routeStack.pop();
      historyBack = false;
      routeStack[routeStack.length - 1] = hash;
    } else if (routeStack.at(-2) === hash) routeStack.pop();
    else if (routeStack.at(-1) !== hash) routeStack.push(hash);
    render();
  });

  globalThis.addEventListener("storage", (event) => {
    if (
      event.key !== null &&
      event.key !== "krill-mobile-hosts-v1" &&
      !event.key?.startsWith("krill-mobile-removed-v1:")
    )
      return;
    if (pairing || landing) {
      pool.sync();
      update();
      return;
    }
    if (!endpoint.reloadHosts()) return;
    pool.sync();
    const entry = pool.get(endpoint.profiles().find((h) => h.active)?.id);
    if (transport !== entry?.transport) {
      closeSheet();
      pendingHostAction = null;
      clearHost(false);
      credentials = null;
      transport = createTransport();
      if (entry) activateEntry(entry);
      else {
        state.connection = { phase: "idle", message: "Not connected" };
      }
      routeStack = ["#/"];
      go("/", true);
    } else update();
  });

  const editable = (node) =>
    node?.isContentEditable ||
    node?.matches?.(
      "textarea,input:not([type=button]):not([type=submit]):not([type=file]):not([type=checkbox]):not([type=radio]):not([type=range]),select",
    );
  const updates = (M.update = M.updates.create({
    endpoint,
    resume: () => transport.resume(),
    blocked: () => !credentials || !!pairing || transport.blocked,
    busy: () =>
      productPending > 0 ||
      transport.updateBusy ||
      pool.updateBusy ||
      dialog.open ||
      !!scanner ||
      M.terminal.updateBusy("") ||
      [...hostViews.values()].some(
        (v) =>
          v.drafts.size ||
          [...(v.chatCache?.values() || [])].some(
            (e) =>
              e.sending || e.modelPending ||
              e.questionSending ||
              e.questionDraft?.changed ||
              e.questionDraft?.selected?.length ||
              e.photo ||
              e.live,
          ),
      ) ||
      [...(state.chatCache?.values() || [])].some(
        (e) =>
          e.sending || e.modelPending ||
          e.questionSending ||
          e.questionDraft?.changed ||
          e.questionDraft?.selected?.length ||
          e.photo ||
          e.live,
      ) ||
      !!document.querySelector(
        ".chat-opt[aria-pressed=true],.file-row[aria-pressed=true]",
      ) ||
      (editable(document.activeElement) && !!document.activeElement.value) ||
      [
        ...document.querySelectorAll(
          "textarea,input,select,[contenteditable=true]",
        ),
      ].some(
        (n) =>
          !n.readOnly &&
          editable(n) &&
          !n.matches(
            ".chat-input,.command-input,.live-capture,input[type=search],select",
          ) &&
          (n.isContentEditable || !!n.value),
      ),
    capture: () => ({
      drafts: [...state.drafts],
      terminalDrafts: M.terminal
        .snapshotDrafts()
        .filter(
          (row) =>
            Array.isArray(row) &&
            row.length === 2 &&
            typeof row[0] === "string" &&
            typeof row[1] === "string",
        ),
      ui: { ...state.ui },
      view: M.updates.captureView(document),
      disclosures: [...(state.chatCache || [])].map(([id, entry]) => [
        id,
        [...(entry.disclosures || [])],
      ]),
    }),
    restore: (saved) => {
      if (
        !Array.isArray(saved.drafts) ||
        !Array.isArray(saved.terminalDrafts) ||
        saved.drafts.some(
          (row) =>
            !Array.isArray(row) ||
            row.length !== 2 ||
            !(
              (Number.isSafeInteger(row[0]) && row[0] > 0) ||
              (typeof row[0] === "string" && row[0].length > 0)
            ) ||
            typeof row[1] !== "string",
        ) ||
        saved.terminalDrafts.some(
          (row) =>
            !Array.isArray(row) ||
            row.length !== 2 ||
            typeof row[0] !== "string" ||
            typeof row[1] !== "string",
        )
      )
        throw Error("Invalid update state");
      state.drafts = new Map(saved.drafts);
      M.terminal.restoreDrafts(saved.terminalDrafts);
      if (typeof saved.ui?.search === "string")
        state.ui.search = saved.ui.search;
      if (typeof saved.ui?.filter === "string")
        state.ui.filter = saved.ui.filter;
      if (
        Array.isArray(saved.ui?.projects) &&
        saved.ui.projects.every((k) => typeof k === "string")
      )
        state.ui.projects = saved.ui.projects;
      else if (typeof saved.ui?.project === "string" && saved.ui.project)
        state.ui.projects = [saved.ui.project];
      for (const [id, entries] of saved.disclosures || [])
        if (Number.isSafeInteger(id) && Array.isArray(entries))
          state.chatCache = new Map([
            ...(state.chatCache || []),
            [
              id,
              {
                offset: 0,
                items: [],
                agent: "",
                bound: false,
                disclosures: new Map(
                  entries.filter(
                    (row) =>
                      Array.isArray(row) &&
                      typeof row[0] === "string" &&
                      typeof row[1] === "boolean",
                  ),
                ),
              },
            ],
          ]);
      M.updates.restoreView(document, saved.view);
    },
  }));
  updates.restore();
  updates.start();

  applyPreferences();
  if (pairing) startPairing();
  let hiddenAt = 0;
  receiveEntry();
  const resume = (e) => {
    if (document.hidden) {
      hiddenAt = Date.now();
      return;
    }
    const stale =
      e?.type === "online" || (hiddenAt > 0 && Date.now() - hiddenAt > 10000);
    pool.resume(stale);
    if (credentials && !pairing && !pool.owns(transport))
      transport.resume(stale);
    hiddenAt = 0;
    receiveEntry();
  };
  document.addEventListener("visibilitychange", resume);
  globalThis.addEventListener("pageshow", resume);
  globalThis.addEventListener("online", resume);
  render();
  if (!pairing && credentials && !pool.owns(transport)) transport.connect();
})();

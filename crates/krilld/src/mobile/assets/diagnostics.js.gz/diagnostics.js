// Browser-only automatic operational diagnostics. Never serialize exceptions or URLs.
(() => {
  const M = (globalThis.KrillMobile ||= {});
  if (M.diagnostics) return;
  const ENDPOINT = "https://errors.krill.page/v1/mobile-events",
    KEY = "krill-mobile-error-reporting-v1",
    OUTBOX = "krill-mobile-error-outbox-v1";
  const phases = new Set([
    "idle",
    "discovery",
    "socket_open",
    "challenge",
    "authentication",
    "ipc",
    "snapshot",
    "rpc",
    "runtime",
    "resource",
  ]);
  const routes = new Set(["relay", "tailscale", "direct", "unknown"]);
  const reasons = new Set([
    "websocket_error",
    "websocket_closed",
    "timeout",
    "http_error",
    "auth_required",
    "auth_rejected",
    "protocol_error",
    "network_offline",
    "runtime_error",
    "unhandled_rejection",
    "resource_error",
    "unknown",
  ]);
  const codes = new Set([
    "mobile_connect_failed",
    "mobile_discovery_failed",
    "mobile_auth_failed",
    "mobile_rpc_failed",
    "mobile_runtime_error",
    "mobile_unhandled_rejection",
    "mobile_asset_failed",
  ]);
  const names = new Set([
    "Error",
    "TypeError",
    "RangeError",
    "ReferenceError",
    "SyntaxError",
    "URIError",
    "EvalError",
    "DOMException",
  ]);
  const files = new Set([
    "index.html",
    "app.js",
    "client.js",
    "diagnostics.js",
    "crypto.js",
    "storage.js",
    "terminal.js",
    "updates.js",
    "i18n.js",
    "qr.js",
    "sw.js",
    ...["home", "session", "chat", "settings", "workspaces", "details"].map(
      (n) => `screens/${n}.js`,
    ),
  ]);
  const number = (n, min, max) => Number.isInteger(n) && n >= min && n <= max;
  const id = () => {
    try {
      return Array.from(crypto.getRandomValues(new Uint8Array(16)), (n) =>
        n.toString(16).padStart(2, "0"),
      ).join("");
    } catch {
      return null;
    }
  };
  const privacySignal = () =>
    navigator.globalPrivacyControl === true ||
    [navigator.doNotTrack, globalThis.doNotTrack].some(
      (v) => v === "1" || v === "yes",
    );
  // Reserve the preference before collecting. Empty string is an explicit off:
  // replacing any saved value with it cannot grow a full localStorage origin.
  // Never remove this key on opt-out: an absent key means automatic collection.
  function saveChoice(value) {
    const saved = value ? "1" : "";
    try {
      localStorage.setItem(KEY, saved);
      return localStorage.getItem(KEY) === saved;
    } catch {
      // Reclaim only our diagnostic queue, never pairing or other user storage.
      try {
        localStorage.removeItem(OUTBOX);
        localStorage.setItem(KEY, saved);
        return localStorage.getItem(KEY) === saved;
      } catch {
        return false;
      }
    }
  }
  function readChoice() {
    try {
      const saved = localStorage.getItem(KEY);
      if (saved === "" || saved === "off" || saved === "0") {
        if (saved !== "") saveChoice(false);
        return false;
      }
      if (saved === "1") return true;
      if (saved === null || saved === "on") return saveChoice(true);
    } catch {}
    // If storage is blocked or too full to reserve a preference, do not collect.
    // Collection requires space for a persistent opt-out.
    return false;
  }
  let consent = readChoice();
  let queue = [],
    recent = [],
    seen = new Map(),
    timer = null,
    inflight = null,
    retryNotBefore = 0,
    epoch = 0;
  const loopback = () =>
    location.hostname === "localhost" ||
    location.hostname === "[::1]" ||
    /^127\./.test(location.hostname);
  const enabled = () => consent && !privacySignal() && !loopback();
  const build =
    /^\/m\/([0-9a-f]{16})\//.exec(location.pathname)?.[1] || "unversioned";
  const ua = navigator.userAgent || "",
    os = /Android/i.test(ua)
      ? "android"
      : /iPhone|iPad|iPod/i.test(ua) ||
          (/Macintosh/i.test(ua) && navigator.maxTouchPoints > 1)
        ? "ios"
        : /Mac/i.test(ua)
          ? "macos"
          : /Windows/i.test(ua)
            ? "windows"
            : /Linux/i.test(ua)
              ? "linux"
              : "other";
  const browser = /Edg/i.test(ua)
    ? "edge"
    : /Firefox|FxiOS/i.test(ua)
      ? "firefox"
      : /Chrome|CriOS/i.test(ua)
        ? "chrome"
        : /Safari/i.test(ua)
          ? "safari"
          : "other";
  function fields(input = {}) {
    const out = {};
    for (const [key, set] of [
      ["phase", phases],
      ["route", routes],
      ["reason", reasons],
      ["error_name", new Set([...names, "Unknown"])],
      ["source_file", files],
    ])
      if (set.has(input[key])) out[key] = input[key];
    for (const [key, min, max] of [
      ["elapsed_ms", 0, 300000],
      ["retry_count", 0, 10000],
      ["ws_code", 1000, 4999],
      ["http_status", 100, 599],
      ["line", 0, 1000000],
      ["column", 0, 1000000],
    ])
      if (number(input[key], min, max)) out[key] = input[key];
    if (/^[0-9a-f]{32}$/.test(input.attempt_id))
      out.attempt_id = input.attempt_id;
    if (Array.isArray(input.stack_frames))
      out.stack_frames = input.stack_frames
        .slice(0, 8)
        .filter(
          (f) =>
            f &&
            files.has(f.source_file) &&
            number(f.line, 0, 1000000) &&
            number(f.column, 0, 1000000),
        )
        .map((f) => ({
          source_file: f.source_file,
          line: f.line,
          column: f.column,
        }));
    return out;
  }
  // Rebuild every outgoing event through the same closed allowlists.
  function canonical(event) {
    if (
      !event ||
      !codes.has(event.error_code) ||
      !/^[0-9a-f]{32}$/.test(event.event_id)
    )
      return null;
    const input = event.diagnostics || {},
      diagnostics = fields(input);
    if (typeof input.online === "boolean") diagnostics.online = input.online;
    if (
      ["visible", "hidden", "prerender", "unknown"].includes(input.visibility)
    )
      diagnostics.visibility = input.visibility;
    if (
      ["safari", "chrome", "firefox", "edge", "other"].includes(input.browser)
    )
      diagnostics.browser = input.browser;
    if (Array.isArray(input.breadcrumbs))
      diagnostics.breadcrumbs = input.breadcrumbs.slice(-12).map(crumb);
    const clean = {
      event_id: event.event_id,
      process: "krill-mobile",
      kind: "operation_error",
      error_code: event.error_code,
      release: "web",
      build_id: /^[0-9a-f]{16}$/.test(event.build_id)
        ? event.build_id
        : "unversioned",
      os: ["ios", "android", "macos", "windows", "linux", "other"].includes(
        event.os,
      )
        ? event.os
        : "other",
      arch: "other",
      source_loc: null,
      hang_bucket_ms: null,
      native: null,
      diagnostics,
    };
    return new TextEncoder().encode(JSON.stringify(clean)).length <= 4096
      ? clean
      : null;
  }
  function discardLegacyOutbox() {
    try {
      localStorage.removeItem(OUTBOX);
    } catch {}
  }
  function crumb(input) {
    const f = fields(input),
      out = {
        phase: f.phase || "idle",
        reason: f.reason || "unknown",
        elapsed_ms: f.elapsed_ms || 0,
      };
    for (const k of ["ws_code", "http_status"])
      if (f[k] !== undefined) out[k] = f[k];
    return out;
  }
  function clear() {
    epoch++;
    clearTimeout(timer);
    timer = null;
    inflight?.abort();
    inflight = null;
    queue = [];
    retryNotBefore = 0;
    seen.clear();
    discardLegacyOutbox();
  }
  function setEnabled(value) {
    clear();
    const requested = value === true && !privacySignal();
    const saved = saveChoice(requested);
    consent = requested && saved;
    return enabled();
  }
  function schedule(delay = 0) {
    if (!enabled() || timer !== null || inflight || !queue.length) return;
    // Expire old reports even when the server asks for a longer cooldown.
    const expires = Math.max(
      0,
      Math.min(...queue.map((q) => q.at + 1800000)) - Date.now(),
    );
    const wait = Math.min(
      expires,
      Math.max(delay, retryNotBefore - Date.now(), 0),
    );
    timer = setTimeout(() => {
      timer = null;
      void flush();
    }, wait);
  }
  async function flush() {
    if (!enabled()) {
      clear();
      return;
    }
    if (inflight) return;
    queue = queue
      .filter((q) => Date.now() - q.at < 1800000 && q.tries < 4)
      .map((q) => ({ ...q, event: canonical(q.event) }))
      .filter((q) => q.event);
    if (!queue.length) return;
    if (Date.now() < retryNotBefore) {
      schedule();
      return;
    }
    const batch = queue.slice(0, 16),
      controller = new AbortController(),
      version = epoch;
    inflight = controller;
    const timeout = setTimeout(() => controller.abort(), 8000);
    for (const item of batch) item.tries++;
    try {
      const response = await fetch(ENDPOINT, {
        method: "POST",
        mode: "cors",
        credentials: "omit",
        referrerPolicy: "no-referrer",
        cache: "no-store",
        redirect: "error",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          schema_version: 1,
          events: batch.map((q) => q.event),
        }),
        signal: controller.signal,
      });
      if (version !== epoch || !enabled()) return;
      const retryAfter = response.headers?.get?.("Retry-After")?.trim();
      if (
        typeof retryAfter === "string" &&
        /^\d{1,5}$/.test(retryAfter) &&
        Number(retryAfter) <= 86400
      )
        retryNotBefore = Math.max(
          retryNotBefore,
          Date.now() + Math.min(1800000, Number(retryAfter) * 1000),
        );
      if (!response.ok) throw Error();
      const ack = await response.json();
      if (version !== epoch || !enabled()) return;
      if (
        ack.schema_version === 1 &&
        Array.isArray(ack.accepted_ids) &&
        Array.isArray(ack.duplicate_ids)
      ) {
        const ids = new Set([...ack.accepted_ids, ...ack.duplicate_ids]);
        queue = queue.filter((q) => !ids.has(q.event.event_id));
      }
    } catch {
      /* Collector failures are intentionally never reported. */
    } finally {
      clearTimeout(timeout);
      if (version === epoch) {
        inflight = null;
        if (!enabled()) clear();
        else
          schedule(
            Math.min(60000, 1000 * 2 ** Math.max(...batch.map((q) => q.tries))),
          );
      }
    }
  }
  function report(code, input = {}) {
    try {
      if (!codes.has(code)) return;
      const clean = fields(input);
      recent.push({ code, ...clean });
      recent = recent.slice(-32);
      if (!enabled()) return;
      if (inflight?.signal.aborted) return;
      const now = Date.now();
      for (const [key, at] of seen) if (now - at > 60000) seen.delete(key);
      const fingerprint = JSON.stringify([
        code,
        clean.attempt_id,
        clean.phase,
        clean.route,
        clean.reason,
        clean.ws_code,
        clean.http_status,
        clean.error_name,
        clean.source_file,
        clean.line,
      ]);
      if (seen.has(fingerprint)) return;
      const eventId = id();
      if (!eventId) return;
      seen.set(fingerprint, now);
      if (seen.size > 128) seen.delete(seen.keys().next().value);
      const diagnostics = {
        ...clean,
        online: navigator.onLine !== false,
        visibility: ["visible", "hidden", "prerender"].includes(
          document.visibilityState,
        )
          ? document.visibilityState
          : "unknown",
        browser,
      };
      if (Array.isArray(input.breadcrumbs))
        diagnostics.breadcrumbs = input.breadcrumbs.slice(-12).map(crumb);
      const event = {
        event_id: eventId,
        process: "krill-mobile",
        kind: "operation_error",
        error_code: code,
        release: "web",
        build_id: build,
        os,
        arch: "other",
        source_loc: null,
        hang_bucket_ms: null,
        native: null,
        diagnostics,
      };
      if (new TextEncoder().encode(JSON.stringify(event)).length > 4096) return;
      queue.push({ event, at: now, tries: 0 });
      queue = queue.slice(-32);
      schedule();
    } catch {
      /* Diagnostics must never interfere with the application. */
    }
  }
  // An episode is the run of attempts until one succeeds. It files at most
  // one report, held briefly so a quick recovery or a hidden page files none.
  const weight = (code, input) =>
    code === "mobile_auth_failed" || input.reason === "auth_required"
      ? 2
      : input.ws_code || input.http_status
        ? 1
        : 0;
  function attempt(retry = 0, previous) {
    let started = Date.now(),
      lastAt = started,
      attemptId = id(),
      established = false,
      state = { phase: "socket_open", route: "unknown" };
    const episode = previous?.episode.open
      ? previous.episode
      : {
          open: false,
          held: null,
          timer: null,
          away: false,
          inFlight: false,
          flushedWeight: -1,
          crumbs: [],
        };
    episode.inFlight = false;
    const resetPostOk = () => {
      if (established && !episode.open) {
        started = Date.now();
        lastAt = started;
        attemptId = id();
        retry = 0;
        established = false;
      }
    };
    const metadata = (extra) => {
      const now = Date.now();
      if (now - lastAt >= 60000) {
        started += now - lastAt;
        if (episode.away || document.visibilityState === "hidden")
          episode.crumbs = [];
      }
      lastAt = now;
      return {
        ...state,
        attempt_id: attemptId,
        elapsed_ms: Math.min(300000, Math.max(0, now - started)),
        retry_count: Math.min(10000, Math.max(0, retry)),
        ...extra,
      };
    };
    const remember = (input) => {
      episode.away ||= document.visibilityState === "hidden";
      episode.crumbs.push(crumb(input));
      episode.crumbs = episode.crumbs.slice(-12);
    };
    const release = () => {
      clearTimeout(episode.timer);
      const hidden = document.visibilityState === "hidden";
      if (hidden || episode.away || episode.inFlight) {
        episode.away = hidden;
        episode.inFlight = false;
        episode.timer = setTimeout(release, 10000);
        return;
      }
      const held = episode.held;
      episode.held = null;
      if (held) {
        episode.flushedWeight = Math.max(
          episode.flushedWeight ?? -1,
          weight(held.code, held.input),
        );
        report(held.code, { ...held.input, breadcrumbs: episode.crumbs });
      }
    };
    return {
      episode,
      mark(phase, extra = {}) {
        resetPostOk();
        const clean = fields({ ...extra, phase });
        state = {
          phase: clean.phase || state.phase,
          route: clean.route || state.route,
        };
        remember(metadata(clean));
        if (
          episode.open &&
          ["challenge", "authentication", "ipc", "snapshot"].includes(
            clean.phase,
          )
        ) {
          episode.inFlight = true;
          if (episode.held) {
            clearTimeout(episode.timer);
            episode.timer = setTimeout(release, 10000);
          }
        }
      },
      report(code, extra = {}) {
        resetPostOk();
        episode.inFlight = false;
        const input = metadata(extra);
        remember(input);
        if (episode.open) {
          const w = weight(code, input);
          if (episode.held) {
            const heldWeight = weight(episode.held.code, episode.held.input);
            if (
              w > heldWeight ||
              (w === heldWeight &&
                code !== "mobile_discovery_failed" &&
                input.attempt_id !== episode.held.input.attempt_id) ||
              (code === "mobile_rpc_failed" &&
                episode.held.code !== "mobile_auth_failed")
            ) {
              episode.held = { code, input };
              if (code === "mobile_rpc_failed") release();
            }
          } else if (
            w > (episode.flushedWeight ?? -1) ||
            (code === "mobile_rpc_failed" && (episode.flushedWeight ?? -1) < 2)
          ) {
            episode.held = { code, input };
            if (code === "mobile_rpc_failed") release();
            else {
              clearTimeout(episode.timer);
              episode.timer = setTimeout(release, 10000);
            }
          }
          return;
        }
        episode.open = true;
        episode.flushedWeight = -1;
        episode.held = { code, input };
        if (code === "mobile_rpc_failed") release();
        else episode.timer = setTimeout(release, 10000);
      },
      ok() {
        clearTimeout(episode.timer);
        established = true;
        started = Date.now();
        lastAt = started;
        Object.assign(episode, {
          open: false,
          held: null,
          away: false,
          inFlight: false,
          flushedWeight: -1,
          crumbs: [],
        });
      },
    };
  }
  function assetFile(value) {
    if (typeof value !== "string" || !value.trim()) return;
    try {
      const u = new URL(value, location.href),
        base = /^\/m\/[0-9a-f]{16}\//.exec(location.pathname)?.[0] || "/";
      if (u.origin !== location.origin || !u.pathname.startsWith(base)) return;
      return u.pathname.slice(base.length) || undefined;
    } catch {}
  }
  function source(value) {
    const file = assetFile(value);
    if (files.has(file)) return file;
    if (typeof value !== "string" || !value.trim()) return;
    try {
      const u = new URL(value, location.href);
      if (
        u.origin === location.origin &&
        (/^\/m\/[0-9a-f]{16}\/?$/.test(u.pathname) || u.pathname === "/")
      )
        return "index.html";
    } catch {}
  }
  const exception = (error) => {
    const out = { error_name: names.has(error?.name) ? error.name : "Unknown" },
      frames = [];
    if (typeof error?.stack === "string")
      for (const line of error.stack.slice(0, 16000).split("\n").slice(0, 32)) {
        const match = /(https?:\/\/[^\s)]+):(\d+):(\d+)\)?$/.exec(line.trim());
        if (!match) continue;
        const file = source(match[1]),
          row = Number(match[2]),
          column = Number(match[3]);
        if (file && number(row, 0, 1000000) && number(column, 0, 1000000))
          frames.push({ source_file: file, line: row, column });
        if (frames.length === 8) break;
      }
    if (frames.length) out.stack_frames = frames;
    return out;
  };
  M.diagnostics = {
    enabled,
    setEnabled,
    get privacySignal() {
      return privacySignal();
    },
    attempt,
    report,
    exception,
    source,
    get recent() {
      return recent.map((e) => JSON.parse(JSON.stringify(e)));
    },
  };
  globalThis.addEventListener?.(
    "error",
    (event) => {
      try {
        if (event.target && event.target !== globalThis) {
          const asset = assetFile(event.target.src || event.target.href),
            file = files.has(asset) ? asset : undefined;
          // Icons and the manifest are decorative: a failed logo breaks nothing.
          if (file || asset === "app.css")
            report("mobile_asset_failed", {
              phase: "resource",
              reason: "resource_error",
              source_file: file,
            });
          return;
        }
        const details = exception(event.error),
          direct = source(event.filename),
          top = details.stack_frames?.[0],
          srcFile = direct || top?.source_file;
        if (!srcFile && !details.stack_frames?.length) return;
        report("mobile_runtime_error", {
          phase: "runtime",
          reason: "runtime_error",
          ...details,
          source_file: srcFile,
          line: direct ? event.lineno : top?.line,
          column: direct ? event.colno : top?.column,
        });
      } catch {}
    },
    true,
  );
  globalThis.addEventListener?.("unhandledrejection", (event) => {
    try {
      const details = exception(event.reason);
      if (
        !details.stack_frames?.length &&
        typeof event.reason?.stack === "string" &&
        /(?:https?|chrome-extension|moz-extension|safari-(?:web-)?extension):\/\//i.test(
          event.reason.stack,
        )
      )
        return;
      report("mobile_unhandled_rejection", {
        phase: "runtime",
        reason: "unhandled_rejection",
        ...details,
      });
    } catch {}
  });
  globalThis.addEventListener?.("online", () => schedule());
  globalThis.addEventListener?.("storage", (event) => {
    if (event.key !== KEY && event.key !== null) return;
    const value = readChoice();
    if (!value) {
      consent = false;
      clear();
    } else if (!consent) {
      clear();
      consent = true;
    }
  });
  discardLegacyOutbox();
})();
